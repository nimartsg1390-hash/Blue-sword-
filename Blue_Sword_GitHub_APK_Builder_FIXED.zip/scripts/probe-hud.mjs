// Probe HUD fill state after settling
import { createServer } from "node:http";
import { readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import path from "node:path";
import { chromium } from "playwright";

const root = existsSync("dist/public") ? "dist/public" : "dist";
const types = { ".html": "text/html", ".js": "text/javascript", ".css": "text/css", ".png": "image/png", ".json": "application/json", ".svg": "image/svg+xml" };
const server = createServer(async (req, res) => {
  try {
    const p = path.join(root, decodeURIComponent(req.url.split("?")[0] === "/" ? "/index.html" : req.url.split("?")[0]));
    const data = await readFile(p);
    res.writeHead(200, { "content-type": types[path.extname(p)] || "application/octet-stream" });
    res.end(data);
  } catch { res.writeHead(404); res.end("nope"); }
});
await new Promise((r) => server.listen(0, "127.0.0.1", r));
const port = server.address().port;

const browser = await chromium.launch({
  executablePath: process.env.X_BROWSER || "/usr/bin/chromium",
  headless: false,
  args: ["--no-sandbox", "--disable-dev-shm-usage"],
  env: { ...process.env, DISPLAY: process.env.X_DISPLAY || ":98" },
});
const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
const errors = [];
page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
page.on("pageerror", (e) => errors.push(String(e)));
await page.goto(`http://127.0.0.1:${port}/`);
await page.evaluate(() => localStorage.clear());
await page.waitForFunction(() => window.__GAME_READY__, null, { timeout: 30000 });
await page.keyboard.press("Space");
try {
  await page.waitForFunction(() => window.__gameProbe && window.__debug.getState() === "playing", null, { timeout: 15000 });
} catch (e) {
  const dump = await page.evaluate(() => ({
    ready: !!window.__GAME_READY__,
    probe: window.__gameProbe ? window.__gameProbe() : null,
    titleVisible: !!document.querySelector("#title:not(.hidden)"),
    bodyClass: document.body.className,
  }));
  console.log("DIAGNOSTICS:", JSON.stringify(dump));
  throw e;
}
await page.waitForTimeout(3000);

const info = await page.evaluate(() => {
  const q = (s) => document.querySelector(s);
  const cs = (s) => { const el = q(s); if (!el) return null; const c = getComputedStyle(el); return { display: c.display, width: c.width, bg: c.backgroundImage.slice(0, 80), opacity: c.opacity, visibility: c.visibility, inlineW: el.style.width, text: el.textContent }; };
  return {
    state: window.__debug.getState(),
    hp: cs("#hud-hp"),
    hpText: (() => { const el = q("#hud-hp-text"); return el ? el.textContent : null; })(),
    st: cs("#hud-st"),
    xp: cs("#hud-xp"),
    level: (() => { const el = q("#hud-level"); return el ? el.textContent : null; })(),
    quest: (() => { const el = q("#hud-quest"); return el ? { text: el.textContent, display: getComputedStyle(el).display } : null; })(),
    compass: cs("#compass"),
    hudDisplay: getComputedStyle(q("#hud")).display,
    probe: window.__gameProbe(),
  };
});
console.log(JSON.stringify(info, null, 2));
await page.screenshot({ path: "verification-shots/probe-hud.png" });
console.log("console errors:", errors.length, errors.slice(0, 5));
await browser.close();
server.close();
