/**
 * character.ts — procedural humanoid rig built from primitives, animated in code
 * (no external assets): walk/run cycles, 3-hit sword combo, heavy overhead slash,
 * block stance, hit flinch, death. Used by the player and humanoid enemies.
 */
import * as THREE from "three";

export interface RigOptions {
  armor: number;
  armorDark: number;
  cloth: number;       // cape / tabard
  skin: number;
  bladeColor?: number; // emissive blade (undefined = no sword)
  bulky?: number;      // width multiplier for heavies
  height?: number;     // overall scale
}

export interface PoseParams {
  /** 0 idle .. 1 sprint. */
  speed: number;
  /** cycle time (advance externally by speed). */
  cycle: number;
  attackT: number;     // -1 = not attacking, else progress 0..1
  attackKind: number;  // 0,1,2 combo / 3 heavy
  blocking: boolean;
  hitT: number;        // flinch progress 0..1, -1 none
  deadT: number;       // -1 alive, else progress 0..1
  casting: boolean;    // witch raise-staff pose
}

export class HumanoidRig {
  readonly group = new THREE.Group();
  readonly root = new THREE.Group();
  private torso: THREE.Group;
  private head: THREE.Group;
  private armL: THREE.Group;
  private armR: THREE.Group;
  private elbowL: THREE.Group;
  private elbowR: THREE.Group;
  private legL: THREE.Group;
  private legR: THREE.Group;
  private kneeL: THREE.Group;
  private kneeR: THREE.Group;
  private capeSegs: THREE.Mesh[] = [];
  private sword: THREE.Group | null = null;
  private bladeTip = new THREE.Object3D();
  private bladeBase = new THREE.Object3D();
  readonly height: number;

  constructor(opts: RigOptions) {
    const bulk = opts.bulky ?? 1;
    const s = (opts.height ?? 1.8) / 1.8;
    this.height = s * 1.8;

    const matArmor = new THREE.MeshStandardMaterial({ color: opts.armor, roughness: 0.45, metalness: 0.75 });
    const matDark = new THREE.MeshStandardMaterial({ color: opts.armorDark, roughness: 0.6, metalness: 0.5 });
    const matSkin = new THREE.MeshStandardMaterial({ color: opts.skin, roughness: 0.8 });
    const matCloth = new THREE.MeshStandardMaterial({ color: opts.cloth, roughness: 0.9, side: THREE.DoubleSide });

    this.group.add(this.root);
    // the primitive kit faces -Z at rest; flip so rig forward matches the
    // gameplay convention forward(yaw) = (sin yaw, cos yaw)
    this.root.rotation.y = Math.PI;

    const box = (w: number, h: number, d: number, m: THREE.Material, px = 0, py = 0, pz = 0) => {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
      mesh.position.set(px, py, pz);
      mesh.castShadow = true;
      return mesh;
    };

    // hips pivot at ~0.95
    this.torso = new THREE.Group();
    this.torso.position.y = 0.95 * s;
    this.root.add(this.torso);
    const pelvis = box(0.4 * bulk * s, 0.2 * s, 0.26 * bulk * s, matDark, 0, 0.02 * s, 0);
    const chest = box(0.48 * bulk * s, 0.5 * s, 0.3 * bulk * s, matArmor, 0, 0.34 * s, 0);
    const belt = box(0.42 * bulk * s, 0.08 * s, 0.28 * bulk * s, matCloth, 0, 0.12 * s, 0);
    this.torso.add(pelvis, chest, belt);

    // head
    this.head = new THREE.Group();
    this.head.position.y = 0.68 * s;
    this.torso.add(this.head);
    const skull = new THREE.Mesh(new THREE.SphereGeometry(0.16 * s, 12, 10), matSkin);
    skull.castShadow = true;
    const helm = new THREE.Mesh(new THREE.CylinderGeometry(0.17 * s, 0.19 * s, 0.16 * s, 10), matArmor);
    helm.position.y = 0.07 * s;
    helm.castShadow = true;
    const crest = box(0.05 * s, 0.14 * s, 0.3 * s, matCloth, 0, 0.17 * s, 0);
    this.head.add(skull, helm, crest);

    // arms: shoulder pivots at chest sides
    const mkArm = (side: 1 | -1) => {
      const shoulder = new THREE.Group();
      shoulder.position.set(side * 0.3 * bulk * s, 0.55 * s, 0);
      this.torso.add(shoulder);
      const upper = box(0.13 * bulk * s, 0.34 * s, 0.13 * bulk * s, matArmor, 0, -0.16 * s, 0);
      const pad = new THREE.Mesh(new THREE.SphereGeometry(0.11 * bulk * s, 8, 6), matDark);
      pad.castShadow = true;
      const elbow = new THREE.Group();
      elbow.position.y = -0.33 * s;
      shoulder.add(elbow);
      const fore = box(0.11 * bulk * s, 0.3 * s, 0.11 * bulk * s, matSkin, 0, -0.14 * s, 0);
      const hand = new THREE.Group();
      hand.position.y = -0.3 * s;
      elbow.add(fore, hand);
      shoulder.add(upper, pad);
      return { shoulder, elbow, hand };
    };
    const la = mkArm(-1);
    const ra = mkArm(1);
    this.armL = la.shoulder; this.elbowL = la.elbow;
    this.armR = ra.shoulder; this.elbowR = ra.elbow;

    // sword in right hand
    if (opts.bladeColor !== undefined) {
      const sword = new THREE.Group();
      const handle = box(0.05 * s, 0.22 * s, 0.05 * s, matDark, 0, 0, 0);
      const guard = box(0.2 * s, 0.045 * s, 0.06 * s, matArmor, 0, 0.13 * s, 0);
      const bladeMat = new THREE.MeshStandardMaterial({
        color: 0xbfe4ff, emissive: opts.bladeColor, emissiveIntensity: 1.8,
        roughness: 0.15, metalness: 0.6,
      });
      const blade = box(0.075 * s, 1.15 * s, 0.02 * s, bladeMat, 0, 0.13 * s + 0.575 * s, 0);
      sword.add(handle, guard, blade);
      this.bladeBase.position.y = 0.16 * s;
      this.bladeTip.position.y = 0.13 * s + 1.15 * s;
      sword.add(this.bladeBase, this.bladeTip);
      ra.hand.add(sword);
      this.sword = sword;
      // idle grip: arm hangs, blade points forward-down
      sword.rotation.x = Math.PI / 2 + 0.5;
    }

    // legs: hip pivots
    const mkLeg = (side: 1 | -1) => {
      const hip = new THREE.Group();
      hip.position.set(side * 0.13 * bulk * s, -0.02 * s, 0);
      this.torso.add(hip);
      const thigh = box(0.15 * bulk * s, 0.4 * s, 0.16 * bulk * s, matDark, 0, -0.2 * s, 0);
      const knee = new THREE.Group();
      knee.position.y = -0.42 * s;
      hip.add(knee);
      const shin = box(0.13 * bulk * s, 0.42 * s, 0.14 * bulk * s, matArmor, 0, -0.2 * s, 0);
      const boot = box(0.14 * bulk * s, 0.1 * s, 0.24 * bulk * s, matDark, 0, -0.42 * s, 0.04 * s);
      knee.add(shin, boot);
      hip.add(thigh);
      return { hip, knee };
    };
    const ll = mkLeg(-1), rl = mkLeg(1);
    this.legL = ll.hip; this.kneeL = ll.knee;
    this.legR = rl.hip; this.kneeR = rl.knee;

    // cape: 3 chained segments
    if (opts.cloth !== undefined) {
      for (let i = 0; i < 3; i++) {
        const seg = new THREE.Mesh(new THREE.PlaneGeometry(0.44 * s, 0.34 * s), matCloth);
        seg.castShadow = true;
        if (i === 0) {
          seg.position.set(0, 0.55 * s, -0.18 * bulk * s);
          this.torso.add(seg);
        } else {
          seg.position.y = -0.33 * s;
          this.capeSegs[i - 1].add(seg);
        }
        seg.rotation.x = 0.25;
        this.capeSegs.push(seg);
      }
    }
  }

  get hasSword(): boolean {
    return this.sword !== null;
  }

  swordWorld(baseOut: THREE.Vector3, tipOut: THREE.Vector3): void {
    this.bladeBase.getWorldPosition(baseOut);
    this.bladeTip.getWorldPosition(tipOut);
  }

  /** Compute rotations for the frame. */
  pose(p: PoseParams): void {
    const t = p.cycle;
    const sp = p.speed;
    const swing = Math.sin(t);
    const swing2 = Math.sin(t + Math.PI);

    // legs walk
    const legAmp = 0.28 + sp * 0.55;
    this.legL.rotation.x = swing * legAmp * sp;
    this.legR.rotation.x = swing2 * legAmp * sp;
    this.kneeL.rotation.x = Math.max(0, -swing) * 0.9 * sp;
    this.kneeR.rotation.x = Math.max(0, -swing2) * 0.9 * sp;

    // torso: run lean + breathing
    this.torso.rotation.x = sp * 0.16;
    this.torso.rotation.y = swing * 0.06 * sp;
    this.torso.position.y = 0.95 + Math.abs(Math.cos(t)) * 0.05 * sp + Math.sin(t * 0.35) * 0.008;

    // default arms (counter-swing while moving)
    this.armL.rotation.set(swing2 * 0.5 * sp, 0, 0.12);
    this.elbowL.rotation.x = -0.25 - sp * 0.3;
    this.armR.rotation.set(swing * 0.35 * sp, 0, -0.12);
    this.elbowR.rotation.x = -0.2 - sp * 0.2;

    this.head.rotation.x = -sp * 0.1;
    this.head.rotation.y = 0;

    // cape flutter by speed
    for (let i = 0; i < this.capeSegs.length; i++) {
      const flutter = Math.sin(t * 1.7 + i * 1.3) * 0.08 * (0.3 + sp);
      this.capeSegs[i].rotation.x = 0.22 + sp * 0.85 + flutter + i * 0.12;
    }

    // attack overlays
    if (p.attackT >= 0) {
      const a = p.attackT;
      if (p.attackKind === 3) {
        // heavy overhead
        const wind = Math.min(1, a / 0.45);
        const strike = Math.max(0, (a - 0.45) / 0.25);
        this.armR.rotation.x = -2.6 * wind + strike * 3.6;
        this.armR.rotation.z = -0.25;
        this.elbowR.rotation.x = -0.5 + strike * 0.3;
        this.torso.rotation.y = -0.5 * wind + strike * 0.9;
        this.torso.rotation.x += strike * 0.3;
      } else if (p.attackKind === 1) {
        // backhand sweep
        const wind = Math.min(1, a / 0.4);
        const strike = Math.max(0, (a - 0.4) / 0.3);
        this.armR.rotation.set(-1.5 * wind - strike * 0.4, 0.9 * wind - strike * 1.9, -0.5);
        this.elbowR.rotation.x = -0.9;
        this.torso.rotation.y = 0.55 * wind - strike * 1.2;
      } else if (p.attackKind === 2) {
        // spinning thrust
        const wind = Math.min(1, a / 0.42);
        const strike = Math.max(0, (a - 0.42) / 0.3);
        this.armR.rotation.set(-1.35 * wind, -0.4 * wind + strike * 0.5, 0);
        this.elbowR.rotation.x = -0.35;
        this.torso.rotation.y = 0.7 * wind - strike * 1.5;
        this.torso.rotation.x += strike * 0.18;
      } else {
        // slash right-to-left
        const wind = Math.min(1, a / 0.38);
        const strike = Math.max(0, (a - 0.38) / 0.32);
        this.armR.rotation.set(-1.35 * wind - strike * 0.5, -0.8 * wind + strike * 1.8, -0.35);
        this.elbowR.rotation.x = -0.55;
        this.torso.rotation.y = -0.5 * wind + strike * 1.05;
      }
    }

    // block: sword raised across the body
    if (p.blocking && p.attackT < 0) {
      this.armR.rotation.set(-1.15, -0.5, -0.7);
      this.elbowR.rotation.x = -1.1;
      this.armL.rotation.set(-1.0, 0.4, 0.5);
      this.torso.rotation.y = 0.28;
    }

    // cast: left arm raised with staff glow
    if (p.casting) {
      this.armL.rotation.set(-2.6, 0, 0.4);
      this.elbowL.rotation.x = -0.3;
    }

    // hit flinch
    if (p.hitT >= 0) {
      const k = Math.sin(Math.min(1, p.hitT) * Math.PI);
      this.torso.rotation.x -= k * 0.35;
      this.head.rotation.x -= k * 0.3;
    }

    // death: crumple
    if (p.deadT >= 0) {
      const d = Math.min(1, p.deadT);
      this.root.rotation.x = -d * Math.PI / 2 * 0.94;
      this.root.position.y = -d * 0.25;
      this.armL.rotation.set(-d * 1.2, 0, 0.5 * d);
      this.armR.rotation.set(-d * 0.8, 0, -0.4 * d);
    } else {
      this.root.rotation.x = 0;
      this.root.position.y = 0;
    }
  }

  dispose(): void {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | undefined;
      if (mat) mat.dispose();
    });
  }
}
