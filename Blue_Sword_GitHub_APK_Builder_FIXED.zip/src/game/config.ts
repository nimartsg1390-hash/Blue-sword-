/**
 * config.ts — global tuning. Input sensitivity and invert switches live here
 * (sync scripts/verify-game.mjs when changing the WASD mapping).
 */

export const INPUT_CONFIG = {
  MOUSE_SENS_X: 0.0026,
  MOUSE_SENS_Y: 0.0022,
  INVERT_X: false,
  INVERT_Y: false,
} as const;

export const QUALITY = {
  PARTICLES_HIGH: 600,
  PARTICLES_LOW: 180,
  DEGRADE_FPS: 45,
} as const;

export const WORLD = {
  SIZE: 720,            // world is SIZE x SIZE, centered on origin
  SEGMENTS: 160,        // terrain mesh resolution
  WATER_LEVEL: 1.15,
  SNOW_LINE: 16,        // height where snow biome starts
  BORDER_SOFT: 26,      // soft push-back margin near world edge
} as const;

export const PLAYER_CFG = {
  HP: 100,
  STAMINA: 100,
  WALK_SPEED: 5.2,
  RUN_SPEED: 8.6,
  ACCEL: 34,
  TURN_LERP: 12,        // body yaw smoothing
  ROLL_TIME: 0.42,
  ROLL_SPEED: 11.5,
  ROLL_IFRAME: [0.04, 0.3] as const,
  ROLL_COST: 22,
  BLOCK_DRAIN_MULT: 0.35,
  STAM_REGEN: 26,
  STAM_REGEN_DELAY: 0.55,
  ATTACKS: [
    { dmg: 14, range: 2.6, arc: 1.9, time: 0.42, windup: 0.16, cost: 8 },
    { dmg: 16, range: 2.7, arc: 2.2, time: 0.46, windup: 0.18, cost: 9 },
    { dmg: 26, range: 3.0, arc: 2.4, time: 0.6, windup: 0.26, cost: 13 },
  ],
  HEAVY: { dmg: 42, range: 3.2, arc: 2.6, time: 0.85, windup: 0.42, cost: 30, knock: 6 },
  INTERACT_RANGE: 3.4,
} as const;

export const ENEMY_TYPES = {
  soldier: {
    name: "Hollow Soldier", hp: 55, dmg: 12, speed: 4.4, aggro: 16, attackRange: 2.2,
    windup: 0.55, recover: 0.9, xp: 30, radius: 0.55, height: 1.85,
  },
  witch: {
    name: "Shadow Witch", hp: 38, dmg: 10, speed: 3.4, aggro: 24, attackRange: 15,
    windup: 0.8, recover: 1.4, xp: 42, radius: 0.5, height: 1.75, ranged: true,
  },
  golem: {
    name: "Iron Golem", hp: 150, dmg: 24, speed: 2.6, aggro: 15, attackRange: 3.0,
    windup: 0.95, recover: 1.3, xp: 90, radius: 0.95, height: 2.6,
  },
} as const;

export const BOSS_CFG = {
  name: "Vharzeth, the Shadow Dragon",
  hp: 900, dmg: 26, speed: 5.0, aggro: 60, radius: 3.2,
  xp: 600,
  breathDps: 30, breathRange: 16,
} as const;

export const XP_CURVE = (level: number) => 90 + (level - 1) * 70;

export const SAVE_KEY = "blueSword.save.v1";
export const SETTINGS_KEY = "blueSword.settings.v1";
