/**
 * input.ts — keyboard/mouse + touch input.
 *
 * Fixed control-mapping conventions (sync scripts/verify-game.mjs when changing them):
 *   W / ArrowUp    = move forward (moveZ = +1)
 *   S / ArrowDown  = move backward (moveZ = -1)
 *   A / ArrowLeft  = move left (moveX = -1)
 *   D / ArrowRight = move right (moveX = +1)
 *   Mouse right => camera turns right (yaw decreases, right-handed); mouse up => camera looks up.
 *
 * Actions: J / left-click = attack, K = heavy attack, Space = dodge roll, Shift (hold) = block,
 * E = interact, Esc/P = pause, M = mute, Enter/Space = confirm (title screens).
 * Touch: left-half drag = virtual stick, right-half drag = camera; DOM buttons call press()/release().
 */

import { INPUT_CONFIG } from "./config";

const KEYMAP: Record<string, [axis: "moveX" | "moveZ", dir: 1 | -1]> = {
  KeyW: ["moveZ", 1], ArrowUp: ["moveZ", 1],
  KeyS: ["moveZ", -1], ArrowDown: ["moveZ", -1],
  KeyA: ["moveX", -1], ArrowLeft: ["moveX", -1],
  KeyD: ["moveX", 1], ArrowRight: ["moveX", 1],
};

const KEY_ACTIONS: Record<string, string> = {
  KeyJ: "attack",
  KeyK: "heavy",
  Space: "dodge",
  KeyE: "interact",
  Escape: "pause",
  KeyP: "pause",
  KeyM: "mute",
  Enter: "confirm",
};

const BLOCK_KEYS = new Set(["ShiftLeft", "ShiftRight"]);

export class Input {
  /** Normalized movement axes. */
  moveX = 0;
  moveZ = 0;
  yawDelta = 0;
  pitchDelta = 0;
  wheelDelta = 0;
  /** Instantaneous action presses, cleared each frame by clearFrame(). */
  private pressed = new Set<string>();
  /** Held actions (block). */
  private heldSet = new Set<string>();
  /** True when the last input came from touch (UI shows touch controls). */
  usingTouch = false;

  /** Virtual stick state, read by the HUD to draw the joystick. */
  readonly stick = { active: false, x: 0, y: 0, ox: 0, oy: 0 };

  private touchMoveId: number | null = null;
  private touchAimId: number | null = null;
  private touchMoveOrigin = { x: 0, y: 0 };
  private touchAimOrigin = { x: 0, y: 0 };
  private lastAim = { x: 0, y: 0 };
  private mouseDownAt = 0;

  /** Multipliers applied to camera sensitivity (settings). */
  sensX = 1;
  sensY = 1;
  /** Runtime invert switches (settings). */
  invertX = false;
  invertY = false;
  /** Swap the touch move/aim halves for left-handed play. */
  leftHanded = false;

  private unsubscribe: Array<() => void> = [];

  constructor(private target: HTMLElement = document.body) {
    const on = <T extends Event>(
      el: Window | Document | HTMLElement,
      type: string,
      fn: (e: T) => void,
      opts?: AddEventListenerOptions,
    ) => {
      const handler = fn as EventListener;
      el.addEventListener(type, handler, opts);
      this.unsubscribe.push(() => el.removeEventListener(type, handler, opts));
    };

    on<KeyboardEvent>(window, "keydown", (e) => {
      if (e.repeat) return;
      this.usingTouch = false;
      if (KEYMAP[e.code]) {
        this.heldKeys.add(e.code);
        this.recomputeAxes();
        // block browser scrolling on game keys
        if (e.code.startsWith("Arrow") || e.code === "Space") e.preventDefault();
      }
      if (BLOCK_KEYS.has(e.code)) this.heldSet.add("block");
      const a = KEY_ACTIONS[e.code];
      if (a) this.pressed.add(a);
    });
    on<KeyboardEvent>(window, "keyup", (e) => {
      this.heldKeys.delete(e.code);
      if (BLOCK_KEYS.has(e.code)) this.heldSet.delete("block");
      this.recomputeAxes();
    });
    on(window, "blur", () => this.resetAll());
    on(document, "visibilitychange", () => { if (document.hidden) this.resetAll(); });

    on<MouseEvent>(window, "mousemove", (e) => {
      if (document.pointerLockElement || e.buttons > 0) {
        const sx = INPUT_CONFIG.MOUSE_SENS_X * this.sensX * (INPUT_CONFIG.INVERT_X !== this.invertX ? -1 : 1);
        const sy = INPUT_CONFIG.MOUSE_SENS_Y * this.sensY * (INPUT_CONFIG.INVERT_Y !== this.invertY ? -1 : 1);
        this.yawDelta -= e.movementX * sx;
        this.pitchDelta += -e.movementY * sy;
      }
    });
    on<WheelEvent>(window, "wheel", (e) => { this.wheelDelta += Math.sign(e.deltaY); }, { passive: true });

    on<MouseEvent>(this.target, "mousedown", (e) => {
      this.usingTouch = false;
      if (e.button === 0) {
        this.pressed.add("attack");
        this.mouseDownAt = performance.now();
      } else if (e.button === 2) {
        this.heldSet.add("block");
      }
    });
    on<MouseEvent>(window, "mouseup", (e) => {
      if (e.button === 2) this.heldSet.delete("block");
    });
    on(this.target, "contextmenu", (e) => e.preventDefault());

    on<TouchEvent>(target, "touchstart", (e) => this.onTouch(e, true), { passive: true });
    on<TouchEvent>(target, "touchmove", (e) => this.onTouch(e, false), { passive: true });
    on<TouchEvent>(target, "touchend", (e) => this.onTouchEnd(e), { passive: true });
    on<TouchEvent>(target, "touchcancel", (e) => this.onTouchEnd(e), { passive: true });
  }

  private heldKeys = new Set<string>();

  dispose(): void {
    for (const off of this.unsubscribe) off();
    this.unsubscribe = [];
    this.pressed.clear();
    this.resetAll();
  }

  /** Programmatic press (touch buttons). */
  press(action: string): void {
    this.usingTouch = true;
    this.pressed.add(action);
    if (action === "block") this.heldSet.add("block");
  }
  release(action: string): void {
    if (action === "block") this.heldSet.delete("block");
  }

  /** True if the action was pressed this frame. */
  consume(action: string): boolean {
    if (this.pressed.has(action)) {
      this.pressed.delete(action);
      return true;
    }
    return false;
  }
  peek(action: string): boolean {
    return this.pressed.has(action);
  }
  isHeld(action: string): boolean {
    return this.heldSet.has(action);
  }

  /** Called at end of each update tick — clears per-frame deltas and presses. */
  clearFrame(): void {
    this.pressed.clear();
    this.yawDelta = 0;
    this.pitchDelta = 0;
    this.wheelDelta = 0;
  }

  resetAll(): void {
    this.heldKeys.clear();
    this.heldSet.clear();
    this.moveX = 0;
    this.moveZ = 0;
    this.yawDelta = 0;
    this.pitchDelta = 0;
    this.stick.active = false;
    this.stick.x = 0;
    this.stick.y = 0;
  }

  private recomputeAxes(): void {
    let x = 0, z = 0;
    for (const code of this.heldKeys) {
      const m = KEYMAP[code];
      if (m) {
        if (m[0] === "moveX") x += m[1];
        else z += m[1];
      }
    }
    this.moveX = clamp(x, -1, 1);
    this.moveZ = clamp(z, -1, 1);
  }

  private onTouch(e: TouchEvent, start: boolean): void {
    this.usingTouch = true;
    const w = window.innerWidth;
    for (const t of Array.from(e.changedTouches)) {
      if (start) {
        const moveSide = this.leftHanded ? t.clientX >= w / 2 : t.clientX < w / 2;
        if (moveSide && this.touchMoveId === null) {
          this.touchMoveId = t.identifier;
          this.touchMoveOrigin = { x: t.clientX, y: t.clientY };
          this.stick.active = true;
          this.stick.ox = t.clientX;
          this.stick.oy = t.clientY;
          this.stick.x = 0;
          this.stick.y = 0;
        } else if (!moveSide && this.touchAimId === null) {
          this.touchAimId = t.identifier;
          this.touchAimOrigin = { x: t.clientX, y: t.clientY };
          this.lastAim = { x: t.clientX, y: t.clientY };
        }
      } else if (t.identifier === this.touchMoveId) {
        this.stick.x = clamp((t.clientX - this.touchMoveOrigin.x) / 60, -1, 1);
        this.stick.y = clamp(-(t.clientY - this.touchMoveOrigin.y) / 60, -1, 1);
        this.moveX = this.stick.x;
        this.moveZ = this.stick.y;
      } else if (t.identifier === this.touchAimId) {
        const dx = t.clientX - this.lastAim.x;
        const dy = t.clientY - this.lastAim.y;
        this.lastAim = { x: t.clientX, y: t.clientY };
        const sx = INPUT_CONFIG.MOUSE_SENS_X * this.sensX * 1.6 * (INPUT_CONFIG.INVERT_X !== this.invertX ? -1 : 1);
        const sy = INPUT_CONFIG.MOUSE_SENS_Y * this.sensY * 1.6 * (INPUT_CONFIG.INVERT_Y !== this.invertY ? -1 : 1);
        this.yawDelta -= dx * sx;
        this.pitchDelta += -dy * sy;
      }
    }
  }

  private onTouchEnd(e: TouchEvent): void {
    for (const t of Array.from(e.changedTouches)) {
      if (t.identifier === this.touchMoveId) {
        this.touchMoveId = null;
        this.stick.active = false;
        this.stick.x = 0;
        this.stick.y = 0;
        this.recomputeAxes();
      } else if (t.identifier === this.touchAimId) {
        this.touchAimId = null;
      }
    }
  }
}

function clamp(v: number, min: number, max: number): number {
  return v < min ? min : v > max ? max : v;
}
