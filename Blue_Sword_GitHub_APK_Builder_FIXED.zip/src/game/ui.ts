/**
 * ui.ts — every piece of DOM chrome: title/pause/settings/upgrades/game-over/victory
 * screens, HUD (HP/stamina/XP, quest tracker, compass, boss bar, prompts, toasts,
 * floating combat text), and customizable mobile touch controls.
 */
import * as THREE from "three";
import type { Settings } from "./save";
import type { HUD } from "./quests";

export interface UIHandlers {
  hasSave(): boolean;
  saveSummary(): string;
  newGame(): void;
  continueGame(): void;
  resume(): void;
  quitToTitle(): void;
  respawn(): void;
  spendPoint(stat: "vigor" | "endurance" | "strength"): void;
  getStats(): { level: number; statPoints: number; stats: { vigor: number; endurance: number; strength: number }; xp: number; xpNeed: number } | null;
  getSettings(): Settings;
  updateSettings(patch: Partial<Settings>): void;
  toggleMute(): boolean;
}

type Screen = "none" | "title" | "pause" | "settings" | "upgrades" | "gameover" | "victory";

interface Floatie { el: HTMLElement; pos: THREE.Vector3; life: number }

export class GameUI implements HUD {
  private root: HTMLElement;
  private handlers: UIHandlers;
  private current: Screen = "none";
  private settingsReturn: Screen = "title";

  private el: Record<string, HTMLElement> = {};
  private floaties: Floatie[] = [];
  private camera: THREE.Camera | null = null;
  private toastTimer = 0;
  private markers: { el: HTMLElement; getPos: () => THREE.Vector3 | null; label: string }[] = [];

  constructor(root: HTMLElement, handlers: UIHandlers) {
    this.root = root;
    this.handlers = handlers;
    this.build();
  }

  setCamera(cam: THREE.Camera): void {
    this.camera = cam;
  }

  // ------------------------------------------------------------ construction
  private h<T extends HTMLElement>(html: string): T {
    const t = document.createElement("template");
    t.innerHTML = html.trim();
    return t.content.firstElementChild as T;
  }

  private build(): void {
    const r = this.root;
    r.innerHTML = "";

    // ===== HUD =====
    const hud = this.h<HTMLElement>(`<div id="hud" class="screen">
      <div id="hud-bars">
        <div class="level-badge" id="hud-level">1</div>
        <div class="bar-stack">
          <div class="bar hp"><div class="fill" id="hud-hp"></div><span class="bar-text" id="hud-hp-text"></span></div>
          <div class="bar st"><div class="fill" id="hud-st"></div></div>
          <div class="bar xp"><div class="fill" id="hud-xp"></div></div>
        </div>
      </div>
      <div id="hud-quest"></div>
      <div id="compass"><div id="compass-strip"></div></div>
      <div id="boss-bar"><div id="boss-name"></div><div class="bar boss"><div class="fill" id="boss-fill"></div></div></div>
      <div id="prompt"></div>
      <div id="toasts"></div>
      <div id="floaties"></div>
      <div id="hud-hint">WASD move · Mouse camera · J/Click attack · K heavy · Space roll · Shift block · E interact · Esc pause</div>
      <div id="hud-mute" title="Mute (M)"></div>
    </div>`);
    r.appendChild(hud);
    this.el.hud = hud;
    this.el.level = hud.querySelector("#hud-level") as HTMLElement;
    this.el.hp = hud.querySelector("#hud-hp") as HTMLElement;
    this.el.hpText = hud.querySelector("#hud-hp-text") as HTMLElement;
    this.el.st = hud.querySelector("#hud-st") as HTMLElement;
    this.el.xp = hud.querySelector("#hud-xp") as HTMLElement;
    this.el.quest = hud.querySelector("#hud-quest") as HTMLElement;
    this.el.prompt = hud.querySelector("#prompt") as HTMLElement;
    this.el.toasts = hud.querySelector("#toasts") as HTMLElement;
    this.el.floaties = hud.querySelector("#floaties") as HTMLElement;
    this.el.hint = hud.querySelector("#hud-hint") as HTMLElement;
    this.el.mute = hud.querySelector("#hud-mute") as HTMLElement;
    this.el.bossBar = hud.querySelector("#boss-bar") as HTMLElement;
    this.el.bossName = hud.querySelector("#boss-name") as HTMLElement;
    this.el.bossFill = hud.querySelector("#boss-fill") as HTMLElement;
    this.el.compassStrip = hud.querySelector("#compass-strip") as HTMLElement;

    // compass strip: cardinal letters + marker slots
    const card = ["N", "E", "S", "W"];
    for (let rep = -1; rep <= 1; rep++) {
      card.forEach((c2, i) => {
        const d = this.h<HTMLElement>(`<span class="card" data-ang="${(rep * 4 + i) * Math.PI / 2}">${c2}</span>`);
        this.el.compassStrip.appendChild(d);
      });
    }
    for (let i = 0; i < 6; i++) {
      const m = this.h<HTMLElement>(`<span class="marker"></span>`);
      this.el.compassStrip.appendChild(m);
      this.markers.push({ el: m, getPos: () => null, label: "" });
    }

    // ===== Title =====
    const title = this.h<HTMLElement>(`<div id="title" class="screen menu-screen">
      <div class="title-block">
        <div class="game-title">BLUE SWORD</div>
        <div class="game-sub">— ULTIMATE LEGACY —</div>
        <div class="menu-buttons">
          <button id="bt-continue" class="mbtn primary">Continue</button>
          <button id="bt-new" class="mbtn">New Game</button>
          <button id="bt-settings-t" class="mbtn">Settings</button>
        </div>
        <div class="title-foot">A 3D action-adventure · Claim the three Sigils and slay the Shadow Dragon</div>
      </div>
    </div>`);
    r.appendChild(title);
    this.el.title = title;
    (title.querySelector("#bt-continue") as HTMLButtonElement).onclick = () => this.handlers.continueGame();
    (title.querySelector("#bt-new") as HTMLButtonElement).onclick = () => this.handlers.newGame();
    (title.querySelector("#bt-settings-t") as HTMLButtonElement).onclick = () => this.openSettings("title");

    // ===== Pause =====
    const pause = this.h<HTMLElement>(`<div id="pause" class="screen menu-screen dim">
      <div class="panel">
        <div class="panel-title">PAUSED</div>
        <button id="bt-resume" class="mbtn primary">Resume</button>
        <button id="bt-upgrades" class="mbtn">Upgrades <span id="upg-points"></span></button>
        <button id="bt-settings-p" class="mbtn">Settings</button>
        <button id="bt-quit" class="mbtn danger">Save &amp; Quit to Title</button>
      </div>
    </div>`);
    r.appendChild(pause);
    this.el.pause = pause;
    (pause.querySelector("#bt-resume") as HTMLButtonElement).onclick = () => this.handlers.resume();
    (pause.querySelector("#bt-upgrades") as HTMLButtonElement).onclick = () => this.show("upgrades");
    (pause.querySelector("#bt-settings-p") as HTMLButtonElement).onclick = () => this.openSettings("pause");
    (pause.querySelector("#bt-quit") as HTMLButtonElement).onclick = () => this.handlers.quitToTitle();

    // ===== Settings =====
    const settings = this.h<HTMLElement>(`<div id="settings" class="screen menu-screen dim">
      <div class="panel wide">
        <div class="panel-title">SETTINGS</div>
        <div class="set-row"><label>Quality</label>
          <select id="set-quality">
            <option value="auto">Auto</option><option value="high">High</option><option value="low">Low</option>
          </select></div>
        <div class="set-row"><label>Camera sensitivity X</label><input id="set-sensx" type="range" min="0.4" max="2" step="0.1"></div>
        <div class="set-row"><label>Camera sensitivity Y</label><input id="set-sensy" type="range" min="0.4" max="2" step="0.1"></div>
        <div class="set-row"><label>Invert camera X</label><input id="set-invx" type="checkbox"></div>
        <div class="set-row"><label>Invert camera Y</label><input id="set-invy" type="checkbox"></div>
        <div class="set-row"><label>Camera shake</label><input id="set-shake" type="checkbox"></div>
        <div class="set-row"><label>Touch button size</label><input id="set-btnscale" type="range" min="0.8" max="1.6" step="0.1"></div>
        <div class="set-row"><label>Left-handed layout</label><input id="set-lefty" type="checkbox"></div>
        <div class="set-row"><label>Mute audio</label><input id="set-mute" type="checkbox"></div>
        <button id="bt-set-back" class="mbtn primary">Back</button>
      </div>
    </div>`);
    r.appendChild(settings);
    this.el.settings = settings;
    const s = this.handlers.getSettings();
    const q = settings.querySelector("#set-quality") as HTMLSelectElement;
    q.value = s.quality;
    q.onchange = () => this.handlers.updateSettings({ quality: q.value as Settings["quality"] });
    const bindRange = (id: string, key: "sensX" | "sensY" | "btnScale") => {
      const inp = settings.querySelector(id) as HTMLInputElement;
      inp.value = String(s[key]);
      inp.oninput = () => this.handlers.updateSettings({ [key]: Number(inp.value) } as Partial<Settings>);
    };
    bindRange("#set-sensx", "sensX");
    bindRange("#set-sensy", "sensY");
    bindRange("#set-btnscale", "btnScale");
    const bindCheck = (id: string, key: "invertX" | "invertY" | "camShake" | "leftHanded" | "muted") => {
      const inp = settings.querySelector(id) as HTMLInputElement;
      inp.checked = s[key];
      inp.onchange = () => {
        if (key === "muted") this.handlers.toggleMute();
        this.handlers.updateSettings({ [key]: inp.checked } as Partial<Settings>);
      };
    };
    bindCheck("#set-invx", "invertX");
    bindCheck("#set-invy", "invertY");
    bindCheck("#set-shake", "camShake");
    bindCheck("#set-lefty", "leftHanded");
    bindCheck("#set-mute", "muted");
    (settings.querySelector("#bt-set-back") as HTMLButtonElement).onclick = () => this.show(this.settingsReturn);

    // ===== Upgrades =====
    const upg = this.h<HTMLElement>(`<div id="upgrades" class="screen menu-screen dim">
      <div class="panel">
        <div class="panel-title">UPGRADES</div>
        <div class="upg-points" id="upg-pts"></div>
        <div class="upg-row"><div><b>Vigor</b><span id="upg-vig-n"></span><small>+16 max HP per point</small></div><button class="mbtn small" id="upg-vig">+</button></div>
        <div class="upg-row"><div><b>Endurance</b><span id="upg-end-n"></span><small>+13 stamina per point</small></div><button class="mbtn small" id="upg-end">+</button></div>
        <div class="upg-row"><div><b>Strength</b><span id="upg-str-n"></span><small>+9% damage per point</small></div><button class="mbtn small" id="upg-str">+</button></div>
        <button id="bt-upg-back" class="mbtn primary">Back</button>
      </div>
    </div>`);
    r.appendChild(upg);
    this.el.upgrades = upg;
    (upg.querySelector("#upg-vig") as HTMLButtonElement).onclick = () => this.spend("vigor");
    (upg.querySelector("#upg-end") as HTMLButtonElement).onclick = () => this.spend("endurance");
    (upg.querySelector("#upg-str") as HTMLButtonElement).onclick = () => this.spend("strength");
    (upg.querySelector("#bt-upg-back") as HTMLButtonElement).onclick = () => this.show("pause");

    // ===== Game over =====
    const go = this.h<HTMLElement>(`<div id="gameover" class="screen menu-screen dark">
      <div class="big-text red">YOU DIED</div>
      <div class="panel-note" id="go-stats"></div>
      <div class="menu-buttons">
        <button id="bt-respawn" class="mbtn primary">Rise Again</button>
        <button id="bt-go-title" class="mbtn">Quit to Title</button>
      </div>
    </div>`);
    r.appendChild(go);
    this.el.gameover = go;
    (go.querySelector("#bt-respawn") as HTMLButtonElement).onclick = () => this.handlers.respawn();
    (go.querySelector("#bt-go-title") as HTMLButtonElement).onclick = () => this.handlers.quitToTitle();

    // ===== Victory =====
    const vic = this.h<HTMLElement>(`<div id="victory" class="screen menu-screen dark">
      <div class="big-text gold">VICTORY</div>
      <div class="panel-note" id="vic-stats"></div>
      <div class="menu-buttons">
        <button id="bt-vic-continue" class="mbtn primary">Keep Exploring</button>
        <button id="bt-vic-new" class="mbtn">New Game</button>
        <button id="bt-vic-title" class="mbtn">Title</button>
      </div>
    </div>`);
    r.appendChild(vic);
    this.el.victory = vic;
    (vic.querySelector("#bt-vic-continue") as HTMLButtonElement).onclick = () => this.handlers.resume();
    (vic.querySelector("#bt-vic-new") as HTMLButtonElement).onclick = () => this.handlers.newGame();
    (vic.querySelector("#bt-vic-title") as HTMLButtonElement).onclick = () => this.handlers.quitToTitle();

    // ===== touch controls =====
    const tc = this.h<HTMLElement>(`<div id="touch-controls">
      <div id="joy-visual"><div id="joy-knob"></div></div>
      <div id="tbtns">
        <button class="tbtn" id="tb-atk">⚔</button>
        <button class="tbtn" id="tb-hvy">💥</button>
        <button class="tbtn" id="tb-roll">↷</button>
        <button class="tbtn hold" id="tb-block">🛡</button>
        <button class="tbtn" id="tb-interact">E</button>
        <button class="tbtn small" id="tb-pause">Ⅱ</button>
      </div>
    </div>`);
    r.appendChild(tc);
    this.el.touch = tc;
    this.el.joy = tc.querySelector("#joy-visual") as HTMLElement;
    this.el.joyKnob = tc.querySelector("#joy-knob") as HTMLElement;
  }

  /** Wire touch buttons to the input system (call once, after input exists). */
  bindTouch(input: {
    press(a: string): void;
    release(a: string): void;
    stick: { active: boolean; x: number; y: number; ox: number; oy: number };
  }): void {
    const bind = (id: string, action: string, hold = false) => {
      const b = this.el.touch.querySelector(id) as HTMLButtonElement;
      const down = (e: Event) => {
        e.preventDefault();
        e.stopPropagation();
        input.press(action);
        if (!hold) setTimeout(() => input.release(action), 50);
      };
      const up = (e: Event) => {
        e.preventDefault();
        input.release(action);
      };
      b.addEventListener("touchstart", down, { passive: false });
      b.addEventListener("touchend", up, { passive: false });
      b.addEventListener("touchcancel", up, { passive: false });
      // also mouse (desktop testing of touch UI)
      b.addEventListener("mousedown", down);
      b.addEventListener("mouseup", up);
    };
    bind("#tb-atk", "attack");
    bind("#tb-hvy", "heavy");
    bind("#tb-roll", "dodge");
    bind("#tb-block", "block", true);
    bind("#tb-interact", "interact");
    bind("#tb-pause", "pause");
  }

  applyControlSettings(scale: number, leftHanded: boolean): void {
    this.el.touch.style.setProperty("--btn-scale", String(scale));
    this.el.touch.classList.toggle("lefty", leftHanded);
  }

  private spend(stat: "vigor" | "endurance" | "strength"): void {
    this.handlers.spendPoint(stat);
    this.refreshUpgrades();
  }

  refreshUpgrades(): void {
    const st = this.handlers.getStats();
    if (!st) return;
    (this.el.upgrades.querySelector("#upg-pts") as HTMLElement).textContent =
      st.statPoints > 0 ? `Stat points: ${st.statPoints}` : "No stat points — level up to earn more";
    (this.el.upgrades.querySelector("#upg-vig-n") as HTMLElement).textContent = ` — ${st.stats.vigor}`;
    (this.el.upgrades.querySelector("#upg-end-n") as HTMLElement).textContent = ` — ${st.stats.endurance}`;
    (this.el.upgrades.querySelector("#upg-str-n") as HTMLElement).textContent = ` — ${st.stats.strength}`;
    const can = st.statPoints > 0;
    for (const id of ["#upg-vig", "#upg-end", "#upg-str"]) {
      (this.el.upgrades.querySelector(id) as HTMLButtonElement).disabled = !can;
    }
    const pts = this.el.pause.querySelector("#upg-points") as HTMLElement;
    if (pts) pts.textContent = st.statPoints > 0 ? `(${st.statPoints})` : "";
  }

  // ------------------------------------------------------------ screen control
  show(screen: Screen): void {
    this.current = screen;
    for (const s of [this.el.title, this.el.pause, this.el.settings, this.el.upgrades, this.el.gameover, this.el.victory]) {
      s.classList.add("hidden");
    }
    this.el.bossBar.classList.toggle("hidden", !this.bossVisible);
    const map: Partial<Record<Screen, HTMLElement>> = {
      title: this.el.title, pause: this.el.pause, settings: this.el.settings,
      upgrades: this.el.upgrades, gameover: this.el.gameover, victory: this.el.victory,
    };
    if (screen !== "none" && map[screen]) map[screen]!.classList.remove("hidden");
    if (screen === "upgrades") this.refreshUpgrades();
    if (screen === "title") this.refreshTitle();
    // HUD only outside title
    this.el.hud.classList.toggle("hidden", screen === "title");
    document.body.classList.toggle("in-menu", screen !== "none");
  }

  get screen(): Screen {
    return this.current;
  }

  private refreshTitle(): void {
    const has = this.handlers.hasSave();
    const bt = this.el.title.querySelector("#bt-continue") as HTMLButtonElement;
    bt.disabled = !has;
    bt.textContent = has ? `Continue — ${this.handlers.saveSummary()}` : "Continue (no save)";
  }

  private openSettings(from: Screen): void {
    this.settingsReturn = from;
    this.show("settings");
  }

  showGameOver(level: number, kills: number, time: number): void {
    (this.el.gameover.querySelector("#go-stats") as HTMLElement).textContent =
      `Level ${level} · ${kills} kills · ${fmtTime(time)}`;
    this.show("gameover");
  }

  showVictory(level: number, kills: number, time: number): void {
    (this.el.victory.querySelector("#vic-stats") as HTMLElement).textContent =
      `The Shadow Dragon has fallen. Level ${level} · ${kills} kills · ${fmtTime(time)}`;
    this.show("victory");
  }

  setMuted(m: boolean): void {
    this.el.mute.textContent = m ? "🔇" : "🔊";
    const cb = this.el.settings.querySelector("#set-mute") as HTMLInputElement;
    if (cb) cb.checked = m;
  }

  // ------------------------------------------------------------ HUD interface
  setQuest(text: string): void {
    this.el.quest.textContent = "◆ " + text;
  }

  setPrompt(text: string | null): void {
    if (text) {
      this.el.prompt.textContent = text;
      this.el.prompt.classList.add("visible");
    } else {
      this.el.prompt.classList.remove("visible");
    }
  }

  toast(text: string, ms = 2600): void {
    const t = this.h<HTMLElement>(`<div class="toast">${text}</div>`);
    this.el.toasts.appendChild(t);
    setTimeout(() => t.classList.add("out"), ms - 400);
    setTimeout(() => t.remove(), ms);
  }

  floatText(x: number, y: number, z: number, text: string, color: string): void {
    if (!this.camera) return;
    const el = this.h<HTMLElement>(`<div class="floatie" style="color:${color}">${text}</div>`);
    this.el.floaties.appendChild(el);
    this.floaties.push({ el, pos: new THREE.Vector3(x, y, z), life: 1.4 });
  }

  showBossBar(name: string): void {
    this.bossVisible = true;
    this.el.bossName.textContent = name;
    this.el.bossBar.classList.remove("hidden");
  }
  setBossHp(frac: number): void {
    this.el.bossFill.style.width = `${frac * 100}%`;
  }
  hideBossBar(): void {
    this.bossVisible = false;
    this.el.bossBar.classList.add("hidden");
  }
  private bossVisible = false;

  updateHUD(hp: number, maxHp: number, st: number, maxSt: number, xp: number, xpNeed: number, level: number): void {
    this.el.hp.style.width = `${Math.max(0, (hp / maxHp) * 100)}%`;
    this.el.hpText.textContent = `${Math.ceil(hp)} / ${maxHp}`;
    this.el.st.style.width = `${Math.max(0, (st / maxSt) * 100)}%`;
    this.el.xp.style.width = `${Math.min(100, (xp / xpNeed) * 100)}%`;
    this.el.level.textContent = String(level);
  }

  /** Update per-frame visuals: floaties, compass, joystick. */
  frame(dt: number, camYaw: number, inputStick: { active: boolean; x: number; y: number; ox: number; oy: number }, usingTouch: boolean): void {
    // floaties rise + project
    if (this.camera) {
      const w = window.innerWidth, h = window.innerHeight;
      for (let i = this.floaties.length - 1; i >= 0; i--) {
        const f = this.floaties[i];
        f.life -= dt;
        f.pos.y += dt * 1.2;
        if (f.life <= 0) {
          f.el.remove();
          this.floaties.splice(i, 1);
          continue;
        }
        _proj.copy(f.pos).project(this.camera);
        if (_proj.z > 1) { f.el.style.opacity = "0"; continue; }
        f.el.style.opacity = String(Math.min(1, f.life));
        f.el.style.transform = `translate(${(_proj.x * 0.5 + 0.5) * w}px, ${(-_proj.y * 0.5 + 0.5) * h}px)`;
      }
    }
    // compass: heading = world bearing of the camera's forward vector
    if (this.camera) {
      const compass = this.el.compassStrip.parentElement as HTMLElement;
      const halfW = compass.clientWidth / 2;
      const heading = camYaw + Math.PI; // camera forward bearing
      const cam = this.camera.position;
      const place = (el: HTMLElement, bearing: number) => {
        let rel = bearing - heading;
        while (rel > Math.PI) rel -= Math.PI * 2;
        while (rel < -Math.PI) rel += Math.PI * 2;
        if (Math.abs(rel) > Math.PI * 0.55) { el.style.display = "none"; return; }
        el.style.display = "block";
        el.style.left = `${halfW + (rel / Math.PI) * halfW}px`;
      };
      // cardinals: N = -Z, E = +X, S = +Z, W = -X
      const cards = this.el.compassStrip.querySelectorAll(".card");
      const cardBearings = [Math.PI, Math.PI / 2, 0, -Math.PI / 2]; // N E S W
      cards.forEach((c2, i) => place(c2 as HTMLElement, cardBearings[i % 4]));
      for (const m of this.markers) {
        const p = m.getPos();
        if (!p) { m.el.style.display = "none"; continue; }
        place(m.el, Math.atan2(p.x - cam.x, p.z - cam.z));
      }
    }
    // joystick visual
    const joy = this.el.joy;
    if (inputStick.active) {
      joy.style.display = "block";
      joy.style.left = `${inputStick.ox - 55}px`;
      joy.style.top = `${inputStick.oy - 55}px`;
      this.el.joyKnob.style.transform = `translate(${inputStick.x * 34}px, ${-inputStick.y * 34}px)`;
    } else {
      joy.style.display = "none";
    }
    // show touch buttons only on touch devices
    this.el.touch.classList.toggle("enabled", usingTouch);
  }

  /** Configure a compass marker slot (world position getter). */
  setMarker(i: number, getPos: () => THREE.Vector3 | null, label: string, cls: string): void {
    const m = this.markers[i];
    if (!m) return;
    m.getPos = getPos;
    m.el.textContent = label;
    m.el.className = `marker ${cls}`;
  }

  setHintVisible(v: boolean): void {
    this.el.hint.style.opacity = v ? "1" : "0";
  }

  dispose(): void {
    this.root.innerHTML = "";
  }
}

const _proj = new THREE.Vector3();

function fmtTime(t: number): string {
  const m = Math.floor(t / 60), s = Math.floor(t % 60);
  return `${m}m ${s}s`;
}
