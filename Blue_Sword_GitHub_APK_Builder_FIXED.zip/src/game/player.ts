/**
 * player.ts — third-person knight: camera-relative movement, orbit camera with terrain
 * avoidance, 3-hit combo + heavy attack + dodge roll (i-frames) + block, stamina,
 * hit reactions, progression stats, sword light + trail feed.
 */
import * as THREE from "three";
import { HumanoidRig } from "./character";
import { PLAYER_CFG } from "./config";
import type { Input } from "./input";
import type { World } from "./world";
import type { FX } from "./effects";
import type { AudioSystem } from "./audio";

/** Something the player can hit (implemented by the enemy manager). */
export interface CombatTargets {
  /** Returns number of targets hit. */
  meleeHit(origin: THREE.Vector3, facing: number, range: number, arc: number, dmg: number, knock: number): number;
}

const _fwd = new THREE.Vector3();
const _right = new THREE.Vector3();
const _move = new THREE.Vector3();
const _tmp = new THREE.Vector3();
const _bladeBase = new THREE.Vector3();
const _bladeTip = new THREE.Vector3();

export class Player {
  readonly rig: HumanoidRig;
  readonly pos = new THREE.Vector3();
  private vel = new THREE.Vector3();
  yaw = Math.PI;          // facing (away from camera, toward -Z)
  camYaw = 0;             // camera orbit: camera sits at +Z, forward = -Z
  camPitch = 0.32;
  camDist = 5.6;

  hp: number = PLAYER_CFG.HP;
  maxHp: number = PLAYER_CFG.HP;
  stamina: number = PLAYER_CFG.STAMINA;
  maxStamina: number = PLAYER_CFG.STAMINA;
  dmgMult: number = 1;

  state: "normal" | "roll" | "attack" | "dead" = "normal";
  blockHeld = false;
  invulnT = 0;
  private rollT = 0;
  private rollDir = new THREE.Vector3(0, 0, 1);
  private attackT = 0;
  private attackIdx = 0;
  private attackHeavy = false;
  private didHit = false;
  private queued = false;
  private staminaWait = 0;
  private hitT = -1;
  private stunT = 0;
  private stepT = 0;
  private cycle = 0;
  private speedSm = 0;
  deadT = -1;
  godMode = false;

  // progression
  level = 1;
  xp = 0;
  statPoints = 0;
  stats = { vigor: 0, endurance: 0, strength: 0 };

  onDeath: (() => void) | null = null;
  onHurt: (() => void) | null = null;
  swordLight: THREE.PointLight;

  constructor() {
    this.rig = new HumanoidRig({
      armor: 0x8b93a8, armorDark: 0x3d4356, cloth: 0x2447c8, skin: 0xd9a077,
      bladeColor: 0x2288ff, height: 1.85,
    });
    this.swordLight = new THREE.PointLight(0x3388ff, 1.4, 7);
    this.swordLight.position.set(0, 1.4, 0.6);
    this.rig.group.add(this.swordLight);
  }

  applyStats(): void {
    this.maxHp = PLAYER_CFG.HP + this.stats.vigor * 16;
    this.maxStamina = PLAYER_CFG.STAMINA + this.stats.endurance * 13;
    this.dmgMult = 1 + this.stats.strength * 0.09;
  }

  spawnAt(x: number, y: number, z: number): void {
    this.pos.set(x, y, z);
    this.vel.set(0, 0, 0);
    this.state = "normal";
    this.hp = this.maxHp;
    this.stamina = this.maxStamina;
    this.deadT = -1;
    this.hitT = -1;
  }

  gainXp(amount: number): boolean {
    this.xp += amount;
    const need = (lv: number) => 90 + (lv - 1) * 70;
    let leveled = false;
    while (this.xp >= need(this.level)) {
      this.xp -= need(this.level);
      this.level++;
      this.statPoints++;
      leveled = true;
    }
    if (leveled) {
      this.applyStats();
      this.hp = Math.min(this.maxHp, this.hp + this.maxHp * 0.4);
      this.stamina = this.maxStamina;
    }
    return leveled;
  }

  update(dt: number, input: Input, world: World, fx: FX, audio: AudioSystem, targets: CombatTargets): void {
    if (this.state === "dead") {
      this.deadT += dt;
      this.rig.pose(this.pose(fx));
      this.syncTransform();
      return;
    }

    // ---- camera orbit
    this.camYaw += input.yawDelta;
    this.camPitch = THREE.MathUtils.clamp(this.camPitch + input.pitchDelta, -0.5, 1.15);
    this.camDist = THREE.MathUtils.clamp(this.camDist + input.wheelDelta * 0.6, 3.2, 9);

    const blocked = this.blockHeld && this.state === "normal" && this.stamina > 0;

    // ---- actions
    if (this.stunT > 0) {
      this.stunT -= dt;
    } else if (this.state === "normal") {
      this.blockHeld = input.isHeld("block") && this.stamina > 1;
      if (input.consume("dodge") && this.stamina >= PLAYER_CFG.ROLL_COST) {
        this.startRoll(input);
      } else if (input.consume("heavy") && this.stamina >= PLAYER_CFG.HEAVY.cost) {
        this.startAttack(-1, true, audio, fx);
      } else if (input.consume("attack") && this.stamina >= PLAYER_CFG.ATTACKS[0].cost) {
        this.startAttack(0, false, audio, fx);
      }
    } else if (this.state === "attack") {
      // combo buffering
      if (input.consume("attack")) this.queued = true;
      if (input.consume("heavy")) { this.queued = true; this.attackHeavy = true; }
    }

    // ---- state machines
    if (this.state === "roll") {
      this.rollT += dt;
      const sp = PLAYER_CFG.ROLL_SPEED * (1 - this.rollT / PLAYER_CFG.ROLL_TIME * 0.45);
      this.vel.x = this.rollDir.x * sp;
      this.vel.z = this.rollDir.z * sp;
      this.invulnT = (this.rollT >= PLAYER_CFG.ROLL_IFRAME[0] && this.rollT <= PLAYER_CFG.ROLL_IFRAME[1]) ? 0.05 : 0;
      if (this.rollT >= PLAYER_CFG.ROLL_TIME) {
        this.state = "normal";
        this.invulnT = 0;
        // chain a buffered attack out of the roll
        if (this.queued) {
          this.queued = false;
          this.startAttack(this.attackHeavy ? -1 : 0, this.attackHeavy, audio, fx);
          this.attackHeavy = false;
        }
      }
    } else if (this.state === "attack") {
      this.attackT += dt;
      const spec = this.attackHeavy ? PLAYER_CFG.HEAVY : PLAYER_CFG.ATTACKS[this.attackIdx];
      const total = spec.time;
      // lunge forward during strike
      const strikeP = this.attackT / total;
      if (strikeP > 0.3 && strikeP < 0.6) {
        _fwd.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
        this.vel.x = _fwd.x * 3.2;
        this.vel.z = _fwd.z * 3.2;
      } else {
        this.vel.x *= 0.8;
        this.vel.z *= 0.8;
      }
      // hit moment
      if (!this.didHit && this.attackT >= spec.windup) {
        this.didHit = true;
        const range = spec.range, arc = spec.arc;
        const dmg = spec.dmg * this.dmgMult;
        const knock = this.attackHeavy ? PLAYER_CFG.HEAVY.knock : 2.2;
        const hits = targets.meleeHit(this.pos, this.yaw, range, arc, dmg, knock);
        if (hits > 0) {
          fx.hitStop(this.attackHeavy ? 0.09 : 0.05);
          fx.shake(this.attackHeavy ? 0.45 : 0.22);
          audio.sfx(this.attackHeavy ? "heavy" : "hit");
        }
        fx.burst(
          this.pos.x + Math.sin(this.yaw) * range * 0.6, this.pos.y + 1.2,
          this.pos.z + Math.cos(this.yaw) * range * 0.6,
          0x66aaff, this.attackHeavy ? 16 : 7, 4, 1.4, 0.35, 2, 1,
        );
      }
      if (this.attackT >= total) {
        this.state = "normal";
        if (this.queued && !this.attackHeavy && this.attackIdx < PLAYER_CFG.ATTACKS.length - 1 && this.stamina >= PLAYER_CFG.ATTACKS[this.attackIdx + 1].cost) {
          this.queued = false;
          this.startAttack(this.attackIdx + 1, false, audio, fx);
        } else {
          this.queued = false;
          this.attackHeavy = false;
        }
      }
    }

    // ---- movement (normal / block)
    let targetSpeed = 0;
    if (this.state === "normal") {
      const mx = input.moveX, mz = input.moveZ;
      const mag = Math.hypot(mx, mz);
      if (mag > 0.1) {
        // camera-relative
        _fwd.set(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw));
        _right.set(-_fwd.z, 0, _fwd.x);
        _move.set(0, 0, 0).addScaledVector(_right, mx).addScaledVector(_fwd, mz).normalize();
        const run = mag > 0.85 && !blocked;
        targetSpeed = (run ? PLAYER_CFG.RUN_SPEED : PLAYER_CFG.WALK_SPEED) * Math.min(1, mag);
        if (!blocked) {
          this.yaw = lerpAngle(this.yaw, Math.atan2(_move.x, _move.z), Math.min(1, dt * PLAYER_CFG.TURN_LERP));
        }
        this.vel.x += (_move.x * targetSpeed - this.vel.x) * Math.min(1, dt * PLAYER_CFG.ACCEL / 4);
        this.vel.z += (_move.z * targetSpeed - this.vel.z) * Math.min(1, dt * PLAYER_CFG.ACCEL / 4);
      } else {
        this.vel.x *= Math.max(0, 1 - dt * 12);
        this.vel.z *= Math.max(0, 1 - dt * 12);
      }
      // while blocking, face the camera direction
      if (blocked) {
        this.yaw = lerpAngle(this.yaw, this.camYaw + Math.PI, Math.min(1, dt * 10));
      }
    } else if (this.state === "attack" && this.attackT < 0.12) {
      // face camera forward at swing start
      this.yaw = lerpAngle(this.yaw, this.camYaw + Math.PI, Math.min(1, dt * 14));
    }

    // integrate
    this.pos.x += this.vel.x * dt;
    this.pos.z += this.vel.z * dt;
    world.collide(this.pos, 0.45);
    const ground = world.heightAt(this.pos.x, this.pos.z);
    this.pos.y += (ground - this.pos.y) * Math.min(1, dt * 18);

    // stamina
    this.staminaWait -= dt;
    if (this.staminaWait <= 0 && this.state !== "attack" && !(this.state === "roll")) {
      this.stamina = Math.min(this.maxStamina, this.stamina + PLAYER_CFG.STAM_REGEN * dt);
    }
    this.invulnT = Math.max(0, this.invulnT - dt);

    // i-frames visual: brief blink
    this.rig.group.visible = this.invulnT <= 0 || Math.floor(performance.now() / 60) % 2 === 0;

    // footstep sfx
    const speedNow = Math.hypot(this.vel.x, this.vel.z);
    this.speedSm += (Math.min(1, speedNow / PLAYER_CFG.RUN_SPEED) - this.speedSm) * Math.min(1, dt * 8);
    if (speedNow > 2 && this.state === "normal") {
      this.stepT -= dt * speedNow;
      if (this.stepT <= 0) {
        this.stepT = 2.4;
        audio.sfx("step");
      }
    }
    this.cycle += dt * (4 + this.speedSm * 7.5);

    this.hitT = this.hitT >= 0 ? this.hitT + dt * 4 : -1;
    if (this.hitT > 1) this.hitT = -1;

    this.rig.pose(this.pose(fx));
    this.syncTransform();
  }

  private pose(fx: FX): Parameters<HumanoidRig["pose"]>[0] {
    const attacking = this.state === "attack";
    const spec = attacking ? (this.attackHeavy ? PLAYER_CFG.HEAVY : PLAYER_CFG.ATTACKS[this.attackIdx]) : PLAYER_CFG.ATTACKS[0];
    return {
      speed: this.state === "roll" ? 0.4 : this.speedSm,
      cycle: this.cycle,
      attackT: attacking ? Math.min(1, this.attackT / spec.time) : -1,
      attackKind: attacking ? (this.attackHeavy ? 3 : this.attackIdx) : 0,
      blocking: this.blockHeld && this.state === "normal",
      hitT: this.hitT,
      deadT: this.state === "dead" ? this.deadT : -1,
      casting: false,
    };
  }

  private syncTransform(): void {
    this.rig.group.position.copy(this.pos);
    this.rig.group.rotation.y = this.yaw;
    if (this.state === "roll") {
      // full body roll around the movement axis
      const p = this.rollT / PLAYER_CFG.ROLL_TIME;
      this.rig.root.rotation.x = -p * Math.PI * 2;
      this.rig.group.position.y = this.pos.y + Math.sin(p * Math.PI) * 0.3;
    }
  }

  private startRoll(input: Input): void {
    this.state = "roll";
    this.rollT = 0;
    this.stamina -= PLAYER_CFG.ROLL_COST;
    this.staminaWait = PLAYER_CFG.STAM_REGEN_DELAY;
    const mx = input.moveX, mz = input.moveZ;
    if (Math.hypot(mx, mz) > 0.15) {
      _fwd.set(-Math.sin(this.camYaw), 0, -Math.cos(this.camYaw));
      _right.set(-_fwd.z, 0, _fwd.x);
      this.rollDir.set(0, 0, 0).addScaledVector(_right, mx).addScaledVector(_fwd, mz).normalize();
      this.yaw = Math.atan2(this.rollDir.x, this.rollDir.z);
    } else {
      this.rollDir.set(Math.sin(this.yaw), 0, Math.cos(this.yaw));
    }
  }

  private startAttack(idx: number, heavy: boolean, audio: AudioSystem, fx: FX): void {
    this.state = "attack";
    this.attackT = 0;
    this.didHit = false;
    this.attackHeavy = heavy;
    this.attackIdx = Math.max(0, idx);
    const spec = heavy ? PLAYER_CFG.HEAVY : PLAYER_CFG.ATTACKS[this.attackIdx];
    this.stamina -= spec.cost;
    this.staminaWait = PLAYER_CFG.STAM_REGEN_DELAY + spec.time;
    audio.sfx(heavy ? "heavy" : "attack");
    fx.burst(this.pos.x, this.pos.y + 1.3, this.pos.z, 0x3388ff, 4, 2, 1.2, 0.3, 0, 1);
  }

  /** Returns actual damage taken after block mitigation. */
  takeDamage(amount: number, fromX: number, fromZ: number, audio: AudioSystem, fx: FX): number {
    if (this.state === "dead" || this.invulnT > 0 || this.godMode) return 0;
    // block check: attacker must be in front while blocking
    if (this.blockHeld && this.stamina > 0 && this.state === "normal") {
      const toAtk = Math.atan2(fromX - this.pos.x, fromZ - this.pos.z);
      let diff = Math.abs(angDiff(toAtk, this.yaw));
      if (diff < 1.3) {
        const chip = Math.round(amount * 0.15);
        this.stamina = Math.max(0, this.stamina - amount * PLAYER_CFG.BLOCK_DRAIN_MULT);
        this.staminaWait = PLAYER_CFG.STAM_REGEN_DELAY;
        audio.sfx("block");
        fx.burst(this.pos.x + Math.sin(this.yaw), this.pos.y + 1.2, this.pos.z + Math.cos(this.yaw), 0xaaccff, 10, 5, 1.6, 0.3, 3);
        fx.shake(0.18);
        if (this.stamina <= 0) {
          // guard break
          this.stunT = 1.1;
          this.hitT = 0;
          audio.sfx("hurt");
        }
        this.hp -= chip;
        this.afterDamage(audio, fx);
        return chip;
      }
    }
    this.hp -= amount;
    this.hitT = 0;
    this.stunT = 0.32;
    // knockback away from attacker
    _tmp.set(this.pos.x - fromX, 0, this.pos.z - fromZ).normalize();
    this.vel.x += _tmp.x * 5;
    this.vel.z += _tmp.z * 5;
    audio.sfx("hurt");
    fx.shake(0.4);
    fx.burst(this.pos.x, this.pos.y + 1.2, this.pos.z, 0xff5544, 12, 5, 1.8, 0.5, 5);
    this.afterDamage(audio, fx);
    return amount;
  }

  private afterDamage(audio: AudioSystem, fx: FX): void {
    this.onHurt?.();
    if (this.hp <= 0) {
      this.hp = 0;
      this.state = "dead";
      this.deadT = 0;
      this.rig.group.visible = true;
      audio.sfx("lose");
      fx.shake(0.8);
      this.onDeath?.();
    }
  }

  heal(v: number): void {
    this.hp = Math.min(this.maxHp, this.hp + v);
  }

  /** Update the camera transform (called after update with the scene camera). */
  updateCamera(cam: THREE.PerspectiveCamera, world: World, fx: FX, dt: number): void {
    const cy = this.camYaw, cp = this.camPitch;
    _tmp.set(
      this.pos.x + Math.sin(cy) * Math.cos(cp) * this.camDist,
      this.pos.y + 1.6 + Math.sin(cp) * this.camDist,
      this.pos.z + Math.cos(cy) * Math.cos(cp) * this.camDist,
    );
    // keep camera above terrain
    const minY = world.heightAt(_tmp.x, _tmp.z) + 0.5;
    if (_tmp.y < minY) _tmp.y = minY;
    // smooth
    cam.position.lerp(_tmp, Math.min(1, dt * 14));
    // screen shake
    if (fx.trauma > 0) {
      const s = fx.trauma * fx.trauma * 0.5;
      cam.position.x += (Math.random() - 0.5) * s;
      cam.position.y += (Math.random() - 0.5) * s;
      cam.position.z += (Math.random() - 0.5) * s;
    }
    _fwd.set(this.pos.x, this.pos.y + 1.5, this.pos.z);
    cam.lookAt(_fwd);
  }

  swordWorld(baseOut: THREE.Vector3, tipOut: THREE.Vector3): void {
    this.rig.swordWorld(baseOut, tipOut);
  }

  isAttacking(): boolean {
    return this.state === "attack" && this.attackT < (this.attackHeavy ? PLAYER_CFG.HEAVY : PLAYER_CFG.ATTACKS[this.attackIdx]).time * 0.8;
  }

  dispose(): void {
    this.rig.dispose();
  }
}

function lerpAngle(a: number, b: number, t: number): number {
  return a + angDiff(b, a) * t;
}
function angDiff(a: number, b: number): number {
  let d = a - b;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}
