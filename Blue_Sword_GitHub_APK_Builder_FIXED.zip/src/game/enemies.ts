/**
 * enemies.ts — enemy AI (Hollow Soldier melee, Shadow Witch ranged, Iron Golem heavy)
 * with patrol/aggro/windup/strike/recover/stagger states, pooled projectiles, and the
 * multi-phase Shadow Dragon boss (fire breath, wing slam, claw, minion summons).
 */
import * as THREE from "three";
import { HumanoidRig } from "./character";
import { ENEMY_TYPES, BOSS_CFG } from "./config";
import type { Player, CombatTargets } from "./player";
import type { World } from "./world";
import type { FX } from "./effects";
import type { AudioSystem } from "./audio";
import { mulberry32 } from "./rng";

type EnemyType = keyof typeof ENEMY_TYPES;
type AiState = "idle" | "chase" | "windup" | "strike" | "recover" | "stagger" | "dead";

const _v = new THREE.Vector3();
const _v2 = new THREE.Vector3();

// ---------------------------------------------------------------- enemy
class Enemy {
  readonly rig: HumanoidRig;
  readonly pos = new THREE.Vector3();
  readonly type: EnemyType;
  readonly spec: {
    name: string; hp: number; dmg: number; speed: number; aggro: number;
    attackRange: number; windup: number; recover: number; xp: number;
    radius: number; height: number; ranged?: boolean;
  };
  hp: number = 1;
  yaw = 0;
  state: AiState = "idle";
  private stateT = 0;
  private cycle = 0;
  private speedSm = 0;
  private deadT = -1;
  private hitT = -1;
  private strikeDone = false;
  anchor = new THREE.Vector3();
  homeYaw = 0;
  engaged = false;
  eyeGlow: THREE.Mesh;

  constructor(type: EnemyType, x: number, y: number, z: number) {
    this.type = type;
    this.spec = ENEMY_TYPES[type];
    this.hp = this.spec.hp;
    this.pos.set(x, y, z);
    this.anchor.copy(this.pos);
    this.yaw = this.homeYaw = Math.random() * Math.PI * 2;

    if (type === "soldier") {
      this.rig = new HumanoidRig({
        armor: 0x4a4f5a, armorDark: 0x24262e, cloth: 0x1c1e24, skin: 0x8a8f99,
        bladeColor: 0xaa3311, height: this.spec.height,
      });
    } else if (type === "witch") {
      this.rig = new HumanoidRig({
        armor: 0x3d2a5c, armorDark: 0x241838, cloth: 0x2a1c44, skin: 0xb9c4d4, height: this.spec.height,
      });
      // staff
      const staff = new THREE.Mesh(
        new THREE.CylinderGeometry(0.03, 0.03, 1.5, 6),
        new THREE.MeshStandardMaterial({ color: 0x2a2033, roughness: 0.8 }),
      );
      const orb = new THREE.Mesh(
        new THREE.SphereGeometry(0.11, 10, 8),
        new THREE.MeshStandardMaterial({ color: 0xb44dff, emissive: 0x9a2eff, emissiveIntensity: 2.4 }),
      );
      orb.position.y = 0.8;
      staff.add(orb);
      staff.rotation.x = Math.PI / 2 + 0.4;
      staff.position.set(0.34, 0.5, 0.1);
      this.attachToTorso(staff);
    } else {
      this.rig = new HumanoidRig({
        armor: 0x5a5f68, armorDark: 0x33373d, cloth: 0x2c2f36, skin: 0x6a7078,
        height: this.spec.height, bulky: 1.55,
      });
    }

    // glowing eyes
    this.eyeGlow = new THREE.Mesh(
      new THREE.SphereGeometry(0.05, 6, 5),
      new THREE.MeshBasicMaterial({ color: type === "witch" ? 0xcc66ff : 0xff4422 }),
    );
    this.eyeGlow.position.set(0, this.spec.height - 0.12, 0.14);
    this.rig.group.add(this.eyeGlow);

    this.rig.group.position.copy(this.pos);
  }

  private attachToTorso(obj: THREE.Object3D): void {
    // torso is the 2nd-level group; find by traversal of known structure
    let torso: THREE.Object3D | null = null;
    const root = this.rig.group.children[0];
    for (const child of root.children) {
      if (child.type === "Group") { torso = child; break; }
    }
    (torso ?? this.rig.group).add(obj);
  }

  update(dt: number, player: Player, world: World, mgr: EnemyManager): void {
    const toPlayer = _v.set(player.pos.x - this.pos.x, 0, player.pos.z - this.pos.z);
    const dist = toPlayer.length();
    this.stateT += dt;
    this.hitT = this.hitT >= 0 ? this.hitT + dt * 4 : -1;
    if (this.hitT > 1) this.hitT = -1;

    if (this.state === "dead") {
      this.deadT += dt;
      this.pose(0, false);
      if (this.deadT > 2.5) {
        this.pos.y -= dt * 0.5; // sink
      }
      this.sync();
      return;
    }

    const aggroR = this.engaged ? 60 : this.spec.aggro;
    const playerAlive = player.state !== "dead";

    switch (this.state) {
      case "idle": {
        if (playerAlive && dist < aggroR) {
          this.state = "chase";
          this.engaged = true;
          this.stateT = 0;
          break;
        }
        // gentle idle sway, occasional turn
        this.yaw = this.homeYaw + Math.sin(this.stateT * 0.4) * 0.5;
        break;
      }
      case "chase": {
        if (!playerAlive) { this.state = "idle"; this.engaged = false; break; }
        const desired = Math.atan2(toPlayer.x, toPlayer.z);
        this.yaw = lerpAngle(this.yaw, desired, Math.min(1, dt * 6));
        const spec = this.spec;
        if (spec.ranged) {
          // witches keep 9-14m distance
          if (dist > 14) this.moveForward(spec.speed, dt, world);
          else if (dist < 8) this.moveForward(-spec.speed * 0.8, dt, world);
          else {
            // strafe
            _v2.set(-toPlayer.z, 0, toPlayer.x).normalize();
            this.pos.addScaledVector(_v2, Math.sin(this.stateT * 0.7) * spec.speed * 0.5 * dt);
          }
          if (this.stateT > 1.2 && dist < spec.attackRange) {
            this.state = "windup";
            this.stateT = 0;
          }
        } else {
          if (dist > spec.attackRange * 0.9) this.moveForward(spec.speed, dt, world);
          if (dist < spec.attackRange && this.stateT > 0.25) {
            this.state = "windup";
            this.stateT = 0;
          }
        }
        break;
      }
      case "windup": {
        // face player, telegraph
        const desired = Math.atan2(toPlayer.x, toPlayer.z);
        this.yaw = lerpAngle(this.yaw, desired, Math.min(1, dt * 8));
        if (this.stateT >= this.spec.windup) {
          this.state = "strike";
          this.stateT = 0;
          this.strikeDone = false;
          if (this.spec.ranged) mgr.fireBolt(this);
        }
        break;
      }
      case "strike": {
        if (!this.strikeDone && this.stateT > 0.12) {
          this.strikeDone = true;
          if (!this.spec.ranged && playerAlive && dist < this.spec.attackRange + 0.7) {
            // arc check
            const toP = Math.atan2(toPlayer.x, toPlayer.z);
            if (Math.abs(angDiff(toP, this.yaw)) < 1.2) {
              player.takeDamage(this.spec.dmg, this.pos.x, this.pos.z, mgr.audio, mgr.fx);
            }
          }
          if (this.type === "golem") {
            mgr.fx.shake(0.35);
            mgr.fx.burst(this.pos.x + Math.sin(this.yaw) * 2, this.pos.y + 0.3, this.pos.z + Math.cos(this.yaw) * 2, 0x998877, 14, 6, 2, 0.5, 7);
            mgr.audio.sfx("hit");
          }
        }
        if (this.stateT > 0.32) {
          this.state = "recover";
          this.stateT = 0;
        }
        break;
      }
      case "recover": {
        if (this.stateT >= this.spec.recover) {
          this.state = "chase";
          this.stateT = 0.4;
        }
        break;
      }
      case "stagger": {
        if (this.stateT >= 0.45) {
          this.state = "chase";
          this.stateT = 0;
        }
        break;
      }
    }

    // gravity to terrain
    const g = world.heightAt(this.pos.x, this.pos.z);
    this.pos.y += (g - this.pos.y) * Math.min(1, dt * 14);
    world.collide(this.pos, this.spec.radius);

    const moving = this.state === "chase" ? 1 : 0;
    this.speedSm += (moving - this.speedSm) * Math.min(1, dt * 6);
    this.cycle += dt * (3 + this.speedSm * 6);

    this.pose(this.speedSm, !!this.spec.ranged && (this.state === "windup" || this.state === "strike"));
    this.sync();

    // windup telegraph: eyes flare
    const em = this.eyeGlow.material as THREE.MeshBasicMaterial;
    em.color.setHex(this.state === "windup" ? 0xffff66 : this.type === "witch" ? 0xcc66ff : 0xff4422);
  }

  private moveForward(speed: number, dt: number, world: World): void {
    this.pos.x += Math.sin(this.yaw) * speed * dt;
    this.pos.z += Math.cos(this.yaw) * speed * dt;
  }

  private pose(speed: number, casting: boolean): void {
    const windup = this.state === "windup" ? Math.min(1, this.stateT / this.spec.windup) : 0;
    const strike = this.state === "strike" ? Math.min(1, this.stateT / 0.3) : 0;
    this.rig.pose({
      speed,
      cycle: this.cycle,
      attackT: this.state === "windup" || this.state === "strike" ? Math.min(1, 0.3 + strike * 0.7) : -1,
      attackKind: this.type === "golem" ? 3 : 0,
      blocking: false,
      hitT: this.hitT,
      deadT: this.deadT,
      casting: casting && windup > 0.2,
    });
  }

  private sync(): void {
    this.rig.group.position.copy(this.pos);
    this.rig.group.rotation.y = this.yaw;
  }

  /** Returns true if this hit killed the enemy. */
  takeDamage(dmg: number, fromX: number, fromZ: number, knock: number, mgr: EnemyManager): boolean {
    if (this.state === "dead") return false;
    this.hp -= dmg;
    this.hitT = 0;
    this.engaged = true;
    if (this.state !== "strike" || this.type !== "golem") {
      this.state = "stagger";
      this.stateT = 0;
    }
    _v2.set(this.pos.x - fromX, 0, this.pos.z - fromZ).normalize();
    const kb = this.type === "golem" ? knock * 0.25 : knock;
    this.pos.x += _v2.x * kb * 0.14;
    this.pos.z += _v2.z * kb * 0.14;
    mgr.fx.burst(this.pos.x, this.pos.y + 1.1, this.pos.z, 0xffaa44, 8, 4, 1.5, 0.4, 5);
    if (this.hp <= 0) {
      this.hp = 0;
      this.state = "dead";
      this.deadT = 0;
      mgr.audio.sfx("enemyDie");
      mgr.fx.burst(this.pos.x, this.pos.y + 1, this.pos.z, 0xff6633, 22, 6, 2, 0.8, 4);
      return true;
    }
    return false;
  }

  get alive(): boolean {
    return this.state !== "dead";
  }

  dispose(): void {
    this.rig.dispose();
  }
}

// ---------------------------------------------------------------- boss
export class Boss {
  readonly group = new THREE.Group();
  readonly pos = new THREE.Vector3();
  hp: number = BOSS_CFG.hp;
  maxHp: number = BOSS_CFG.hp;
  active = false;
  dead = false;
  yaw = 0;
  private state: "dormant" | "intro" | "hover" | "breath" | "slam" | "claw" | "summon" | "stagger" | "dying" = "dormant";
  private stateT = 0;
  private flap = 0;
  private wingL: THREE.Group;
  private wingR: THREE.Group;
  private head: THREE.Group;
  private jaw: THREE.Mesh;
  private tailSegs: THREE.Group[] = [];
  private fireLight: THREE.PointLight;
  private eyeMat: THREE.MeshBasicMaterial;
  private summonDone = [false, false];
  private hoverTarget = new THREE.Vector3();
  private breathDir = new THREE.Vector3();
  private flameT = 0;

  constructor(private world: World, private fx: FX, private audio: AudioSystem) {
    const dark = new THREE.MeshStandardMaterial({ color: 0x1f1626, roughness: 0.55, metalness: 0.25 });
    const membrane = new THREE.MeshStandardMaterial({
      color: 0x3a1c5c, roughness: 0.7, side: THREE.DoubleSide,
      emissive: 0x5511aa, emissiveIntensity: 0.25,
    });
    const g = this.group;

    const body = new THREE.Mesh(new THREE.SphereGeometry(2.4, 14, 10), dark);
    body.scale.set(1, 0.85, 1.5);
    body.castShadow = true;
    g.add(body);

    // neck + head
    this.head = new THREE.Group();
    this.head.position.set(0, 1.2, 2.6);
    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.9, 2.2, 8), dark);
    neck.rotation.x = Math.PI / 3.2;
    neck.position.set(0, 0.4, -0.6);
    const skull = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.8, 1.8), dark);
    skull.position.set(0, 0.9, 0.6);
    skull.castShadow = true;
    this.jaw = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.3, 1.5), dark);
    this.jaw.position.set(0, 0.45, 0.7);
    const hornGeo = new THREE.ConeGeometry(0.16, 1.1, 5);
    const hornL = new THREE.Mesh(hornGeo, membrane);
    hornL.position.set(-0.4, 1.4, -0.1);
    hornL.rotation.x = -0.7;
    const hornR = hornL.clone();
    hornR.position.x = 0.4;
    this.eyeMat = new THREE.MeshBasicMaterial({ color: 0xff2222 });
    const eyeGeo = new THREE.SphereGeometry(0.12, 8, 6);
    const eyeL = new THREE.Mesh(eyeGeo, this.eyeMat);
    eyeL.position.set(-0.35, 0.95, 1.35);
    const eyeR = eyeL.clone();
    eyeR.position.x = 0.35;
    this.head.add(neck, skull, this.jaw, hornL, hornR, eyeL, eyeR);
    g.add(this.head);

    // wings: shoulder group -> membrane plane + bone
    const mkWing = (side: 1 | -1) => {
      const shoulder = new THREE.Group();
      shoulder.position.set(side * 1.6, 1.1, 0.6);
      const bone = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.2, 4.6, 6), dark);
      bone.rotation.z = side * Math.PI / 2;
      bone.position.x = side * 2.2;
      const mem = new THREE.Mesh(new THREE.PlaneGeometry(4.4, 2.6, 4, 2), membrane);
      mem.position.set(side * 2.2, -0.7, -0.3);
      mem.rotation.y = side * 0.15;
      if (side === -1) mem.scale.x = -1;
      const tipBone = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.13, 2.6, 5), dark);
      tipBone.rotation.z = side * Math.PI / 2.4;
      tipBone.position.set(side * 3.6, -1.1, -0.6);
      shoulder.add(bone, mem, tipBone);
      g.add(shoulder);
      return shoulder;
    };
    this.wingL = mkWing(-1);
    this.wingR = mkWing(1);

    // tail chain
    let parent: THREE.Object3D = g;
    for (let i = 0; i < 4; i++) {
      const seg = new THREE.Group();
      seg.position.set(0, i === 0 ? -0.2 : 0, i === 0 ? -2.6 : -1.5);
      const m = new THREE.Mesh(new THREE.ConeGeometry(0.55 - i * 0.11, 1.7, 6), dark);
      m.rotation.x = -Math.PI / 2;
      m.position.z = -0.8;
      seg.add(m);
      parent.add(seg);
      parent = seg;
      this.tailSegs.push(seg);
    }
    // legs
    for (const sx of [-1, 1]) {
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.45, 1.8, 6), dark);
      leg.position.set(sx * 1.3, -1.6, 0.9);
      g.add(leg);
    }

    this.fireLight = new THREE.PointLight(0xff5511, 0, 30);
    this.fireLight.position.set(0, 1, 4);
    g.add(this.fireLight);

    const a = this.worldBossSpawn();
    this.pos.copy(a);
    g.position.copy(this.pos);
    g.visible = false;
  }

  private worldBossSpawn(): THREE.Vector3 {
    const c = { x: 268, z: 60 };
    return new THREE.Vector3(c.x, this.world.heightAt(c.x, c.z) + 7, c.z);
  }

  activate(): void {
    if (this.active || this.dead) return;
    this.active = true;
    this.group.visible = true;
    this.state = "intro";
    this.stateT = 0;
    this.audio.sfx("bossRoar");
    this.fx.shake(0.9);
  }

  update(dt: number, player: Player, mgr: EnemyManager): void {
    if (this.dead || !this.active) return;
    this.stateT += dt;
    this.flap += dt * 5;

    const toPlayer = _v.set(player.pos.x - this.pos.x, 0, player.pos.z - this.pos.z);
    const dist = toPlayer.length();
    const desiredYaw = Math.atan2(toPlayer.x, toPlayer.z);
    const groundY = this.world.heightAt(this.pos.x, this.pos.z);

    // wing flap base pose
    const flap = Math.sin(this.flap) * 0.55;
    this.wingL.rotation.z = -flap - 0.15;
    this.wingR.rotation.z = flap + 0.15;
    for (let i = 0; i < this.tailSegs.length; i++) {
      this.tailSegs[i].rotation.y = Math.sin(this.flap * 0.6 + i * 0.9) * 0.18;
    }
    this.group.position.copy(this.pos);

    switch (this.state) {
      case "intro": {
        this.pos.y += (groundY + 5 - this.pos.y) * Math.min(1, dt * 1.5);
        this.yaw = lerpAngle(this.yaw, desiredYaw, Math.min(1, dt * 2));
        if (this.stateT > 2.2) { this.state = "hover"; this.stateT = 0; }
        break;
      }
      case "hover": {
        // pick next attack
        this.yaw = lerpAngle(this.yaw, desiredYaw, Math.min(1, dt * 3));
        this.pos.y += (groundY + 5.5 + Math.sin(this.flap * 0.5) * 0.6 - this.pos.y) * Math.min(1, dt * 2);
        // drift toward player to stay engaged
        if (dist > 14) {
          this.pos.x += (toPlayer.x / dist) * BOSS_CFG.speed * 0.7 * dt;
          this.pos.z += (toPlayer.z / dist) * BOSS_CFG.speed * 0.7 * dt;
        }
        if (this.stateT > 1.4) {
          this.stateT = 0;
          // phase-based choice
          const p2 = this.hp < this.maxHp * 0.5;
          const roll = Math.random();
          if (dist < 7) { this.state = "claw"; }
          else if (p2 && roll < 0.35) { this.state = "slam"; this.hoverTarget.set(player.pos.x, 0, player.pos.z); }
          else if (roll < 0.72) { this.state = "breath"; }
          else { this.state = "slam"; this.hoverTarget.set(player.pos.x, 0, player.pos.z); }
        }
        break;
      }
      case "breath": {
        this.yaw = lerpAngle(this.yaw, desiredYaw, Math.min(1, dt * 1.6));
        // descend slightly, aim
        this.pos.y += (groundY + 3.6 - this.pos.y) * Math.min(1, dt * 2);
        // breathe fire during middle window
        if (this.stateT > 0.7 && this.stateT < 2.6) {
          this.jaw.rotation.x = 0.55;
          this.flameT -= dt;
          if (this.flameT <= 0) {
            this.flameT = 0.05;
            this.breathDir.set(Math.sin(this.yaw), -0.12, Math.cos(this.yaw));
            const mx = this.pos.x + this.breathDir.x * 4.5;
            const my = this.pos.y + 1.4;
            const mz = this.pos.z + this.breathDir.z * 4.5;
            this.fx.burst(mx, my, mz, 0xff6622, 10, 7, 3, 0.55, -1, 1);
            this.fx.burst(mx, my, mz, 0xffcc33, 5, 5, 2.4, 0.4, -1, 1);
            if (Math.random() < 0.25) this.audio.sfx("fire");
          }
          this.fireLight.intensity = 3.2;
          // damage cone
          if (player.state !== "dead") {
            const px = player.pos.x - this.pos.x, pz = player.pos.z - this.pos.z;
            const pd = Math.hypot(px, pz);
            if (pd < BOSS_CFG.breathRange && pd > 2) {
              const pAng = Math.atan2(px, pz);
              if (Math.abs(angDiff(pAng, this.yaw)) < 0.45) {
                player.takeDamage(BOSS_CFG.breathDps * dt, this.pos.x, this.pos.z, this.audio, this.fx);
              }
            }
          }
        } else {
          this.jaw.rotation.x = 0;
          this.fireLight.intensity = Math.max(0, this.fireLight.intensity - dt * 6);
        }
        if (this.stateT > 3.1) { this.state = "hover"; this.stateT = 0; }
        break;
      }
      case "slam": {
        // swoop to target point then slam
        const tx = this.hoverTarget.x, tz = this.hoverTarget.z;
        const ty = this.world.heightAt(tx, tz);
        _v2.set(tx - this.pos.x, 0, tz - this.pos.z);
        const d = _v2.length();
        if (d > 1.5) {
          this.pos.addScaledVector(_v2.normalize(), Math.min(d, BOSS_CFG.speed * 1.9 * dt));
          this.pos.y += (ty + 8 - this.pos.y) * Math.min(1, dt * 3);
          this.yaw = lerpAngle(this.yaw, Math.atan2(_v2.x, _v2.z), Math.min(1, dt * 4));
        } else {
          // dive
          this.pos.y += (ty + 1.6 - this.pos.y) * Math.min(1, dt * 8);
          if (this.pos.y < ty + 2.2 && !this.strikeDone2) {
            this.strikeDone2 = true;
            this.fx.shake(0.85);
            this.fx.hitStop(0.06);
            this.audio.sfx("bossRoar");
            this.fx.burst(tx, ty + 0.5, tz, 0x8844ff, 30, 9, 3, 0.8, 6);
            // AoE damage
            const pd = Math.hypot(player.pos.x - tx, player.pos.z - tz);
            if (pd < 6.5 && player.state !== "dead") {
              player.takeDamage(BOSS_CFG.dmg, tx, tz, this.audio, this.fx);
            }
          }
          if (this.strikeDone2 && this.stateT > 2.2) {
            this.strikeDone2 = false;
            this.state = "hover";
            this.stateT = 0.3;
          }
        }
        break;
      }
      case "claw": {
        this.yaw = lerpAngle(this.yaw, desiredYaw, Math.min(1, dt * 5));
        this.pos.y += (groundY + 2.2 - this.pos.y) * Math.min(1, dt * 4);
        if (this.stateT > 0.5 && !this.strikeDone2) {
          this.strikeDone2 = true;
          if (dist < 8.5 && player.state !== "dead") {
            player.takeDamage(BOSS_CFG.dmg * 0.8, this.pos.x, this.pos.z, this.audio, this.fx);
          }
          this.fx.burst(this.pos.x + Math.sin(this.yaw) * 4, this.pos.y + 1, this.pos.z + Math.cos(this.yaw) * 4, 0xaa66ff, 16, 7, 2.5, 0.5, 5);
          this.fx.shake(0.4);
        }
        if (this.stateT > 1.0) {
          this.strikeDone2 = false;
          this.state = "hover";
          this.stateT = 0;
        }
        break;
      }
      case "stagger": {
        if (this.stateT > 0.8) { this.state = "hover"; this.stateT = 0; }
        break;
      }
      case "dying": {
        this.pos.y -= dt * 2.2;
        this.group.rotation.z += dt * 0.35;
        this.fireLight.intensity = Math.max(0, this.fireLight.intensity - dt * 2);
        if (this.stateT > 3.2) {
          this.dead = true;
          this.group.visible = false;
        }
        break;
      }
    }

    // summons at 66% / 33%
    if (this.state !== "dying" && this.state !== "dormant") {
      const frac = this.hp / this.maxHp;
      if (frac < 0.66 && !this.summonDone[0]) { this.summonDone[0] = true; mgr.summonAdds(this.pos, 2); this.audio.sfx("bossRoar"); }
      if (frac < 0.33 && !this.summonDone[1]) { this.summonDone[1] = true; mgr.summonAdds(this.pos, 3); this.audio.sfx("bossRoar"); }
      // phase 2: redder eyes + faster
      if (frac < 0.5) {
        this.eyeMat.color.setHex(0xff5522);
        this.flap += dt * 2.5;
      }
    }
    this.group.rotation.y = this.yaw;
  }

  private strikeDone2 = false;

  /** Reset after the player dies mid-fight. */
  reset(): void {
    this.hp = this.maxHp;
    this.active = false;
    this.dead = false;
    this.state = "dormant";
    this.stateT = 0;
    this.strikeDone2 = false;
    this.summonDone = [false, false];
    this.group.visible = false;
    this.group.rotation.z = 0;
    this.pos.copy(this.worldBossSpawn());
    this.group.position.copy(this.pos);
    this.eyeMat.color.setHex(0xff2222);
  }

  takeDamage(dmg: number, mgr: EnemyManager): boolean {
    if (this.dead || !this.active || this.state === "intro" || this.state === "dying") return false;
    this.hp -= dmg;
    mgr.fx.burst(this.pos.x, this.pos.y + 1.5, this.pos.z, 0xffaa44, 8, 5, 2, 0.4, 4);
    if (this.hp <= 0) {
      this.hp = 0;
      this.state = "dying";
      this.stateT = 0;
      this.audio.sfx("bossRoar");
      mgr.fx.shake(1);
      mgr.fx.burst(this.pos.x, this.pos.y + 2, this.pos.z, 0xff6622, 60, 10, 3.5, 1.4, 3);
      return true;
    }
    // occasional stagger
    if (Math.random() < 0.12 && this.state === "hover") {
      this.state = "stagger";
      this.stateT = 0;
    }
    return false;
  }

  dispose(): void {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | undefined;
      if (mat) mat.dispose();
    });
  }
}

// ---------------------------------------------------------------- manager
interface Bolt { alive: boolean; pos: THREE.Vector3; vel: THREE.Vector3; life: number; mesh: THREE.Mesh }

export class EnemyManager implements CombatTargets {
  readonly enemies: Enemy[] = [];
  readonly boss: Boss;
  private bolts: Bolt[] = [];
  private boltGroup = new THREE.Group();
  onKill: ((xp: number, x: number, y: number, z: number) => void) | null = null;

  constructor(
    private scene: THREE.Scene,
    private world: World,
    readonly fx: FX,
    readonly audio: AudioSystem,
  ) {
    this.boss = new Boss(world, fx, audio);
    scene.add(this.boss.group);
    scene.add(this.boltGroup);
    // projectile pool
    const geo = new THREE.SphereGeometry(0.22, 8, 6);
    const mat = new THREE.MeshBasicMaterial({ color: 0xbb44ff });
    for (let i = 0; i < 12; i++) {
      const mesh = new THREE.Mesh(geo, mat);
      mesh.visible = false;
      this.boltGroup.add(mesh);
      this.bolts.push({ alive: false, pos: new THREE.Vector3(), vel: new THREE.Vector3(), life: 0, mesh });
    }
    this.spawnAll();
  }

  private spawnAll(): void {
    const rng = mulberry32(2024);
    const H = (x: number, z: number) => this.world.heightAt(x, z);

    // shrine guardian camps: 2 soldiers + 1 witch each
    for (const s of this.world.shrines) {
      for (let i = 0; i < 2; i++) {
        const a = rng() * Math.PI * 2;
        this.add("soldier", s.pos.x + Math.cos(a) * (5 + rng() * 3), H(s.pos.x, s.pos.y) + 0.1, s.pos.z + Math.sin(a) * (5 + rng() * 3));
      }
      this.add("witch", s.pos.x + 2, H(s.pos.x + 2, s.pos.z - 4), s.pos.z - 4);
    }
    // roaming meadow packs
    for (let p = 0; p < 6; p++) {
      const a = rng() * Math.PI * 2, r = 70 + rng() * 120;
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      if (this.world.heightAt(x, z) < 2) continue;
      const n = 2 + Math.floor(rng() * 2);
      for (let i = 0; i < n; i++) {
        this.add("soldier", x + (rng() - 0.5) * 8, 0, z + (rng() - 0.5) * 8);
      }
    }
    // golems: mountains + near corrupt approach
    this.add("golem", -40, 0, -180);
    this.add("golem", 170, 0, 40);
    // corrupted lands patrol
    this.add("witch", 220, 0, 20);
    this.add("witch", 230, 0, 100);
    this.add("soldier", 200, 0, 60);
    this.add("soldier", 240, 0, 40);
  }

  private add(type: EnemyType, x: number, y: number, z: number): void {
    const yy = y > -100 ? y : this.world.heightAt(x, z);
    const e = new Enemy(type, x, yy, z);
    this.enemies.push(e);
    this.scene.add(e.rig.group);
  }

  summonAdds(near: THREE.Vector3, count: number): void {
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const x = near.x + Math.cos(a) * 10, z = near.z + Math.sin(a) * 10;
      const type: EnemyType = i % 2 === 0 ? "soldier" : "witch";
      this.add(type, x, 0, z);
      const e = this.enemies[this.enemies.length - 1];
      e.engaged = true;
      e.state = "chase";
      this.fx.burst(x, e.pos.y + 1, z, 0x8844ff, 16, 6, 2.4, 0.7, 3);
    }
  }

  fireBolt(from: Enemy): void {
    for (const b of this.bolts) {
      if (b.alive) continue;
      b.alive = true;
      b.pos.set(from.pos.x, from.pos.y + 1.4, from.pos.z);
      b.vel.set(0, 0, 0);
      b.life = 4;
      b.mesh.visible = true;
      this.audio.sfx("attack");
      return;
    }
  }

  /** Aimed bolts need the player's position: call each frame. */
  private updateBolts(dt: number, player: Player): void {
    for (const b of this.bolts) {
      if (!b.alive) continue;
      b.life -= dt;
      if (b.life <= 0) { b.alive = false; b.mesh.visible = false; continue; }
      // first-frame homing aim toward player, then straight
      if (b.life > 3.85) {
        _v.set(player.pos.x - b.pos.x, player.pos.y + 1.2 - b.pos.y, player.pos.z - b.pos.z).normalize();
        b.vel.copy(_v).multiplyScalar(14);
      }
      b.pos.addScaledVector(b.vel, dt);
      b.mesh.position.copy(b.pos);
      this.fx.burst(b.pos.x, b.pos.y, b.pos.z, 0x9944ff, 1, 0.5, 1.1, 0.25, 0, 0);
      // hit player
      if (player.state !== "dead" && b.pos.distanceToSquared(_v2.set(player.pos.x, player.pos.y + 1.1, player.pos.z)) < 0.8) {
        player.takeDamage(ENEMY_TYPES.witch.dmg, b.pos.x - b.vel.x, b.pos.z - b.vel.z, this.audio, this.fx);
        b.alive = false;
        b.mesh.visible = false;
      }
    }
  }

  /** CombatTargets implementation — player sword swings. */
  meleeHit(origin: THREE.Vector3, facing: number, range: number, arc: number, dmg: number, knock: number): number {
    let hits = 0;
    const test = (cx: number, cz: number, cr: number, cb: (d: number) => boolean): boolean => {
      const dx = cx - origin.x, dz = cz - origin.z;
      const d = Math.hypot(dx, dz);
      if (d > range + cr) return false;
      const ang = Math.atan2(dx, dz);
      if (Math.abs(angDiff(ang, facing)) > arc / 2) return false;
      return cb(d);
    };
    for (const e of this.enemies) {
      if (!e.alive) continue;
      test(e.pos.x, e.pos.z, e.spec.radius, () => {
        hits++;
        if (e.takeDamage(dmg, origin.x, origin.z, knock, this)) {
          this.onKill?.(e.spec.xp, e.pos.x, e.pos.y + 1, e.pos.z);
        }
        return true;
      });
    }
    // boss hitbox
    if (this.boss.active && !this.boss.dead) {
      test(this.boss.pos.x, this.boss.pos.z, BOSS_CFG.radius, () => {
        hits++;
        this.boss.takeDamage(dmg, this);
        return true;
      });
    }
    return hits;
  }

  update(dt: number, player: Player): void {
    for (const e of this.enemies) {
      // skip far-away idle enemies (cheap LOD for AI)
      const d2 = e.pos.distanceToSquared(player.pos);
      if (d2 > 130 * 130 && !e.engaged && e.state === "idle") continue;
      e.update(dt, player, this.world, this);
    }
    this.boss.update(dt, player, this);
    this.updateBolts(dt, player);
  }

  /** True when any enemy is engaged with the player (drives combat music). */
  inCombat(): boolean {
    for (const e of this.enemies) {
      if (e.alive && e.engaged) return true;
    }
    return this.boss.active && !this.boss.dead;
  }

  /** Are there living guardians near a shrine? */
  guardiansNear(x: number, z: number, r: number): boolean {
    for (const e of this.enemies) {
      if (e.alive && Math.hypot(e.pos.x - x, e.pos.z - z) < r) return true;
    }
    return false;
  }

  aliveCount(): number {
    let n = 0;
    for (const e of this.enemies) if (e.alive) n++;
    return n;
  }

  dispose(): void {
    for (const e of this.enemies) {
      this.scene.remove(e.rig.group);
      e.dispose();
    }
    this.boss.dispose();
    this.scene.remove(this.boss.group, this.boltGroup);
    this.boltGroup.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
    });
  }
}

function lerpAngle(a: number, b: number, t: number): number {
  return a + angDiff(b, a) * t;
}
function angDiff(a: number, b: number): number {
  let d = a - b;
  while (d > Math.PI) d -= Math.PI * 2;
  while (d < -Math.PI) d += Math.PI * 2;
  return d;
}
