/**
 * world.ts — the open world: parametric terrain with biomes (meadow forest, snowy
 * north, corrupted east, lake), sky shader with day/night cycle + procedural clouds,
 * dynamic weather (rain, lightning), instanced vegetation, castle ruins, sigil shrines,
 * hidden chests, the boss arena with its gate, and circle colliders.
 */
import * as THREE from "three";
import { mergeGeometries } from "three/addons/utils/BufferGeometryUtils.js";
import { fbm2, mulberry32, pick } from "./rng";
import { WORLD } from "./config";

const SIZE = WORLD.SIZE;
const HALF = SIZE / 2;

// ---------------------------------------------------------------- biome layout
export const LAYOUT = {
  castle: new THREE.Vector2(0, 0),
  mountains: new THREE.Vector2(-30, -250),
  corrupt: new THREE.Vector2(250, 60),
  lake: new THREE.Vector2(-150, 170),
  bossArena: new THREE.Vector2(268, 60),
  shrines: [new THREE.Vector2(-170, -90), new THREE.Vector2(120, 190), new THREE.Vector2(-60, 250)],
  spawn: new THREE.Vector3(14, 0, 52),
} as const;

const gauss = (t: number) => Math.exp(-t * t);

/** mergeGeometries requires uniform indexing — normalize everything to non-indexed. */
function mergeAll(geoms: THREE.BufferGeometry[]): THREE.BufferGeometry {
  return mergeGeometries(geoms.map((g) => (g.index ? g.toNonIndexed() : g)))!;
}
const smooth = (a: number, b: number, x: number) => {
  const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

/** Analytic terrain height — single source of truth for mesh + gameplay queries. */
export function terrainHeight(x: number, z: number): number {
  let h = fbm2(x * 0.012, z * 0.012, 4) * 6.5 + fbm2(x * 0.055, z * 0.055, 2) * 1.1;
  // northern mountain massif
  const md = Math.hypot(x - LAYOUT.mountains.x, z - LAYOUT.mountains.y);
  h += gauss(md / 170) * 30 + gauss(md / 170) * Math.abs(fbm2(x * 0.02 + 9, z * 0.02, 3)) * 22;
  // corrupted east: flatten toward arena
  const ed = Math.hypot(x - LAYOUT.corrupt.x, z - LAYOUT.corrupt.y);
  h = h + (4.2 - h) * gauss(ed / 130);
  // castle plateau
  const cd = Math.hypot(x - LAYOUT.castle.x, z - LAYOUT.castle.y);
  h = h + (7 - h) * smooth(62, 22, cd);
  // lake depression
  const ld = Math.hypot(x - LAYOUT.lake.x, z - LAYOUT.lake.y);
  h -= gauss(ld / 75) * 11;
  // raised rim at world edge (natural boundary instead of invisible walls)
  const r = Math.hypot(x, z);
  h += smooth(HALF - 70, HALF - 14, r) * 46;
  return h;
}

export type Biome = "meadow" | "snow" | "corrupt" | "sand" | "rock";

export function biomeAt(x: number, z: number, h: number): Biome {
  const ed = Math.hypot(x - LAYOUT.corrupt.x, z - LAYOUT.corrupt.y);
  if (ed < 150 && h < 20) return "corrupt";
  if (h < WORLD.WATER_LEVEL + 0.7) return "sand";
  if (h > WORLD.SNOW_LINE || z < -170) return "snow";
  if (h > 11) return "rock";
  return "meadow";
}

// ---------------------------------------------------------------- sky shader
const SKY_VERT = `
varying vec3 vDir;
void main() {
  vDir = position;
  vec4 p = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  gl_Position = p.xyww; // depth = far plane
}`;

const SKY_FRAG = `
varying vec3 vDir;
uniform vec3 sunDir;
uniform float dayFactor;
uniform float cloudCover;
uniform float time;
uniform vec3 fogColor;

float hash(vec2 p) { return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453); }
float vnoise(vec2 p) {
  vec2 i = floor(p), f = fract(p);
  vec2 u = f * f * (3.0 - 2.0 * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x),
             mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y);
}
float fbm(vec2 p) {
  float s = 0.0, a = 0.5;
  for (int i = 0; i < 4; i++) { s += a * vnoise(p); p *= 2.13; a *= 0.5; }
  return s;
}
void main() {
  vec3 dir = normalize(vDir);
  float elev = dir.y;
  vec3 dayZen = vec3(0.20, 0.42, 0.78);
  vec3 dayHor = vec3(0.74, 0.83, 0.92);
  vec3 nightZen = vec3(0.015, 0.02, 0.05);
  vec3 nightHor = vec3(0.07, 0.09, 0.16);
  vec3 zen = mix(nightZen, dayZen, dayFactor);
  vec3 hor = mix(nightHor, dayHor, dayFactor);
  vec3 col = mix(hor, zen, pow(clamp(elev, 0.0, 1.0), 0.55));
  // warm band at the horizon around sunrise/sunset
  float sunLow = 1.0 - abs(sunDir.y);
  float sunset = clamp(1.0 - abs(elev) * 4.0, 0.0, 1.0) * sunLow * (1.0 - abs(dayFactor * 2.0 - 1.0));
  col += vec3(0.9, 0.38, 0.12) * sunset * 0.55;
  // sun disc + glow
  float sd = dot(dir, sunDir);
  col += vec3(1.0, 0.86, 0.6) * pow(clamp(sd, 0.0, 1.0), 350.0) * 3.0 * step(-0.2, sunDir.y + 0.4);
  col += vec3(1.0, 0.75, 0.45) * pow(clamp(sd, 0.0, 1.0), 8.0) * 0.18 * (0.3 + sunLow);
  // moon: opposite-ish
  vec3 md = -sunDir;
  float mdd = dot(dir, normalize(md + vec3(0.25, 0.1, 0.0)));
  col += vec3(0.8, 0.86, 1.0) * pow(clamp(mdd, 0.0, 1.0), 900.0) * 1.6 * (1.0 - dayFactor);
  // clouds
  if (elev > 0.02) {
    vec2 cuv = dir.xz / (elev + 0.18);
    float cl = fbm(cuv * 1.15 + vec2(time * 0.008, time * 0.0035));
    float cover = smoothstep(0.62 - cloudCover * 0.34, 0.88 - cloudCover * 0.2, cl);
    float shade = fbm(cuv * 2.4 + vec2(time * 0.012, 0.0));
    vec3 cloudDay = mix(vec3(1.0, 1.0, 1.0), vec3(0.55, 0.58, 0.66), shade * 0.8);
    vec3 cloudNight = vec3(0.05, 0.06, 0.1);
    vec3 cloudCol = mix(cloudNight, cloudDay, dayFactor);
    // sun-lit cloud edges
    cloudCol += vec3(1.0, 0.7, 0.4) * pow(clamp(sd, 0.0, 1.0), 3.0) * 0.35 * dayFactor;
    col = mix(col, cloudCol, cover * 0.85 * smoothstep(0.02, 0.14, elev));
  }
  gl_FragColor = vec4(col, 1.0);
}`;

// ---------------------------------------------------------------- water shader
const WATER_VERT = `
varying vec3 vPos;
varying vec3 vView;
uniform float time;
void main() {
  vec3 p = position;
  p.y += sin(p.x * 0.14 + time * 1.3) * 0.12 + cos(p.z * 0.11 + time * 0.9) * 0.12;
  vPos = (modelMatrix * vec4(p, 1.0)).xyz;
  vec4 mv = modelViewMatrix * vec4(p, 1.0);
  vView = -mv.xyz;
  gl_Position = projectionMatrix * mv;
}`;

const WATER_FRAG = `
varying vec3 vPos;
varying vec3 vView;
uniform float time;
uniform float dayFactor;
uniform vec3 sunDir;
void main() {
  vec3 n = normalize(vec3(
    sin(vPos.x * 0.35 + time * 1.7) * 0.08 + sin(vPos.z * 0.23 - time * 1.1) * 0.06,
    1.0,
    cos(vPos.z * 0.31 + time * 1.4) * 0.08));
  vec3 v = normalize(vView);
  float fres = pow(1.0 - max(dot(n, v), 0.0), 2.2);
  vec3 deep = mix(vec3(0.012, 0.03, 0.05), vec3(0.05, 0.19, 0.28), dayFactor);
  vec3 sky = mix(vec3(0.05, 0.07, 0.12), vec3(0.5, 0.68, 0.82), dayFactor);
  vec3 col = mix(deep, sky, fres * 0.75 + 0.1);
  vec3 r = reflect(-v, n);
  float spec = pow(max(dot(r, sunDir), 0.0), 90.0);
  col += vec3(1.0, 0.9, 0.7) * spec * 1.4 * dayFactor;
  gl_FragColor = vec4(col, 0.86);
}`;

// ---------------------------------------------------------------- world
export interface CircleCollider { x: number; z: number; r: number }

export interface Shrine {
  id: number;
  pos: THREE.Vector3;
  crystal: THREE.Mesh;
  light: THREE.PointLight;
  claimed: boolean;
}

export interface Chest {
  id: number;
  pos: THREE.Vector3;
  group: THREE.Group;
  lid: THREE.Mesh;
  opened: boolean;
}

export class World {
  readonly group = new THREE.Group();
  readonly colliders: CircleCollider[] = [];
  readonly shrines: Shrine[] = [];
  readonly chests: Chest[] = [];
  readonly bossGate: THREE.Group;
  readonly bossGateCollider: CircleCollider;
  bossGateOpen = false;

  sun: THREE.DirectionalLight;
  hemi: THREE.HemisphereLight;
  moon: THREE.DirectionalLight;

  private skyMat: THREE.ShaderMaterial;
  private waterMat: THREE.ShaderMaterial;
  private stars: THREE.Points;
  private rain: THREE.Points;
  private rainPos: Float32Array;
  private rainAmt = 0;
  private rainTarget = 0;
  private weatherTimer = 40;
  private lightningTimer = 8;
  private flash = 0;
  private time = 0.32; // time of day 0..1 (0.25 = sunrise, 0.5 = noon-ish start)
  private readonly dayLength = 600; // seconds per full day

  private crystals: THREE.Mesh[] = [];
  private torchLights: THREE.PointLight[] = [];
  private gateBarrier: THREE.Mesh;
  private gateLight: THREE.PointLight;

  private grassMat: THREE.MeshStandardMaterial | null = null;

  onThunder: (() => void) | null = null;

  constructor() {
    const rng = mulberry32(1337);

    // --- terrain
    const seg = WORLD.SEGMENTS;
    const geom = new THREE.PlaneGeometry(SIZE, SIZE, seg, seg);
    geom.rotateX(-Math.PI / 2);
    const posAttr = geom.getAttribute("position") as THREE.BufferAttribute;
    const colors = new Float32Array(posAttr.count * 3);
    const c = new THREE.Color();
    for (let i = 0; i < posAttr.count; i++) {
      const x = posAttr.getX(i), z = posAttr.getZ(i);
      const h = terrainHeight(x, z);
      posAttr.setY(i, h);
      const b = biomeAt(x, z, h);
      const n = fbm2(x * 0.09 + 40, z * 0.09, 2) * 0.5 + 0.5;
      switch (b) {
        case "meadow": c.setRGB(0.24 + n * 0.1, 0.4 + n * 0.12, 0.16 + n * 0.06); break;
        case "snow": c.setRGB(0.85 + n * 0.1, 0.88 + n * 0.08, 0.93 + n * 0.05); break;
        case "corrupt": c.setRGB(0.16 + n * 0.06, 0.11 + n * 0.03, 0.2 + n * 0.07); break;
        case "sand": c.setRGB(0.62 + n * 0.1, 0.55 + n * 0.08, 0.4 + n * 0.06); break;
        case "rock": c.setRGB(0.36 + n * 0.1, 0.36 + n * 0.1, 0.38 + n * 0.1); break;
      }
      colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
    }
    geom.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geom.computeVertexNormals();
    const terrainMat = new THREE.MeshStandardMaterial({ vertexColors: true, roughness: 0.95, metalness: 0 });
    const terrain = new THREE.Mesh(geom, terrainMat);
    terrain.receiveShadow = true;
    this.group.add(terrain);

    // --- water
    this.waterMat = new THREE.ShaderMaterial({
      transparent: true,
      uniforms: { time: { value: 0 }, dayFactor: { value: 1 }, sunDir: { value: new THREE.Vector3(0, 1, 0) } },
      vertexShader: WATER_VERT,
      fragmentShader: WATER_FRAG,
    });
    const water = new THREE.Mesh(new THREE.PlaneGeometry(SIZE, SIZE, 48, 48).rotateX(-Math.PI / 2), this.waterMat);
    water.position.y = WORLD.WATER_LEVEL;
    this.group.add(water);

    // --- sky dome
    this.skyMat = new THREE.ShaderMaterial({
      side: THREE.BackSide,
      depthWrite: false,
      uniforms: {
        sunDir: { value: new THREE.Vector3(0, 1, 0) },
        dayFactor: { value: 1 },
        cloudCover: { value: 0.25 },
        time: { value: 0 },
        fogColor: { value: new THREE.Color(0x88aacc) },
      },
      vertexShader: SKY_VERT,
      fragmentShader: SKY_FRAG,
    });
    const sky = new THREE.Mesh(new THREE.SphereGeometry(900, 32, 16), this.skyMat);
    sky.frustumCulled = false;
    this.group.add(sky);

    // --- stars
    {
      const n = 500;
      const sp = new Float32Array(n * 3);
      const srng = mulberry32(77);
      for (let i = 0; i < n; i++) {
        const a = srng() * Math.PI * 2, e = Math.acos(srng() * 0.95);
        sp[i * 3] = Math.sin(e) * Math.cos(a) * 850;
        sp[i * 3 + 1] = Math.cos(e) * 850;
        sp[i * 3 + 2] = Math.sin(e) * Math.sin(a) * 850;
      }
      const sg = new THREE.BufferGeometry();
      sg.setAttribute("position", new THREE.BufferAttribute(sp, 3));
      this.stars = new THREE.Points(sg, new THREE.PointsMaterial({
        color: 0xcdd8ff, size: 1.6, sizeAttenuation: false, transparent: true, opacity: 0, depthWrite: false,
      }));
      this.stars.frustumCulled = false;
      this.group.add(this.stars);
    }

    // --- rain (single pooled Points cloud following the player)
    {
      const n = 700;
      this.rainPos = new Float32Array(n * 3);
      for (let i = 0; i < n; i++) {
        this.rainPos[i * 3] = (Math.random() - 0.5) * 60;
        this.rainPos[i * 3 + 1] = Math.random() * 26;
        this.rainPos[i * 3 + 2] = (Math.random() - 0.5) * 60;
      }
      const rg = new THREE.BufferGeometry();
      rg.setAttribute("position", new THREE.BufferAttribute(this.rainPos, 3).setUsage(THREE.DynamicDrawUsage));
      this.rain = new THREE.Points(rg, new THREE.PointsMaterial({
        color: 0x9db8d8, size: 0.09, transparent: true, opacity: 0, depthWrite: false,
      }));
      this.rain.frustumCulled = false;
      this.rain.visible = false;
      this.group.add(this.rain);
    }

    // --- lights
    this.sun = new THREE.DirectionalLight(0xffffff, 2.6);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.camera.left = -70;
    this.sun.shadow.camera.right = 70;
    this.sun.shadow.camera.top = 70;
    this.sun.shadow.camera.bottom = -70;
    this.sun.shadow.camera.near = 10;
    this.sun.shadow.camera.far = 400;
    this.sun.shadow.bias = -0.0006;
    this.sun.shadow.normalBias = 0.5;
    this.group.add(this.sun, this.sun.target);
    this.moon = new THREE.DirectionalLight(0x8899cc, 0);
    this.group.add(this.moon, this.moon.target);
    this.hemi = new THREE.HemisphereLight(0xbdd4ee, 0x3d4a33, 0.9);
    this.group.add(this.hemi);

    // --- fog
    this.group.parent; // (scene fog set by boot via scene.fog)

    // --- vegetation + rocks (instanced)
    this.buildVegetation(rng);

    // --- castle ruins (merged stone geometry)
    this.buildCastle();

    // --- corrupted boss arena + gate
    this.bossGate = new THREE.Group();
    this.buildArena();
    this.gateBarrier = this.bossGate.children.find((ch) => ch.name === "barrier") as THREE.Mesh;
    this.gateLight = new THREE.PointLight(0x8844ff, 2.4, 26);
    this.gateLight.position.set(0, 4, 0);
    this.bossGate.add(this.gateLight);
    this.bossGateCollider = { x: LAYOUT.bossArena.x - 26, z: LAYOUT.bossArena.y, r: 2.4 };
    this.colliders.push(this.bossGateCollider);

    // --- sigil shrines
    for (let i = 0; i < LAYOUT.shrines.length; i++) this.buildShrine(i, rng);

    // --- hidden chests
    const chestSpots: [number, number][] = [
      [-120, -40], [60, -140], [200, -60], [-220, 120], [40, 240], [150, 130],
    ];
    for (let i = 0; i < chestSpots.length; i++) this.buildChest(i, chestSpots[i][0], chestSpots[i][1]);

    // spawn point height
    LAYOUT.spawn.y = terrainHeight(LAYOUT.spawn.x, LAYOUT.spawn.z);
  }

  // ------------------------------------------------------------ builders
  private buildVegetation(rng: () => number): void {
    // sample helpers
    const place = (
      count: number,
      biome: Biome | "any",
      minH: number, maxH: number,
      avoid: { x: number; z: number; r: number }[],
    ): [number, number, number][] => {
      const out: [number, number, number][] = [];
      let guard = 0;
      while (out.length < count && guard++ < count * 30) {
        const x = (rng() * 2 - 1) * (HALF - 40);
        const z = (rng() * 2 - 1) * (HALF - 40);
        const h = terrainHeight(x, z);
        if (h < minH || h > maxH) continue;
        if (biome !== "any" && biomeAt(x, z, h) !== biome) continue;
        let bad = false;
        for (const a of avoid) {
          if (Math.hypot(x - a.x, z - a.z) < a.r) { bad = true; break; }
        }
        if (bad) continue;
        out.push([x, h, z]);
      }
      return out;
    };

    const avoidAll = [
      { x: LAYOUT.castle.x, z: LAYOUT.castle.y, r: 30 },
      { x: LAYOUT.bossArena.x, z: LAYOUT.bossArena.y, r: 40 },
      ...LAYOUT.shrines.map((s) => ({ x: s.x, z: s.y, r: 12 })),
    ];

    const dummy = new THREE.Object3D();

    const scatter = (
      spots: [number, number, number][],
      geom: THREE.BufferGeometry,
      mat: THREE.Material,
      collideR: number,
      sink = 0.15,
    ): THREE.InstancedMesh => {
      const im = new THREE.InstancedMesh(geom, mat, spots.length);
      im.castShadow = true;
      im.receiveShadow = true;
      for (let i = 0; i < spots.length; i++) {
        const [x, h, z] = spots[i];
        const s = 0.75 + rng() * 0.7;
        dummy.position.set(x, h - sink, z);
        dummy.rotation.set(0, rng() * Math.PI * 2, 0);
        dummy.scale.setScalar(s);
        dummy.updateMatrix();
        im.setMatrixAt(i, dummy.matrix);
        if (collideR > 0) this.colliders.push({ x, z, r: collideR * s });
      }
      im.instanceMatrix.needsUpdate = true;
      this.group.add(im);
      return im;
    };

    // pine (snow): trunk + 2 stacked cones as one merged geometry
    const pineGeo = mergeAll([
      new THREE.CylinderGeometry(0.16, 0.26, 2.2, 6).translate(0, 1.1, 0),
      new THREE.ConeGeometry(1.6, 3.4, 7).translate(0, 3.4, 0),
      new THREE.ConeGeometry(1.15, 2.6, 7).translate(0, 5.3, 0),
    ])!;
    scatter(place(190, "snow", WORLD.WATER_LEVEL + 1, 60, avoidAll), pineGeo,
      new THREE.MeshStandardMaterial({ color: 0x2c4a38, roughness: 0.9 }), 0.4);

    // meadow broadleaf: trunk + blob canopy (purple / orange / green mix via instance color)
    const blobGeo = mergeAll([
      new THREE.CylinderGeometry(0.22, 0.34, 2.6, 6).translate(0, 1.3, 0),
      new THREE.IcosahedronGeometry(2.1, 1).translate(0, 4.1, 0),
      new THREE.IcosahedronGeometry(1.4, 1).translate(1.1, 3.2, 0.4),
    ])!;
    const meadowSpots = place(200, "meadow", WORLD.WATER_LEVEL + 0.8, 11, avoidAll);
    const blobMat = new THREE.MeshStandardMaterial({ roughness: 0.85 });
    const blobIM = scatter(meadowSpots, blobGeo, blobMat, 0.45);
    {
      const cols = [new THREE.Color(0x5a8a3c), new THREE.Color(0x8a4fc9), new THREE.Color(0xd07a2e), new THREE.Color(0x4f7fc9)];
      const cc = new THREE.Color();
      for (let i = 0; i < meadowSpots.length; i++) {
        cc.copy(pick(rng, cols)).offsetHSL(0, 0, (rng() - 0.5) * 0.08);
        blobIM.setColorAt(i, cc);
      }
      blobIM.instanceColor!.needsUpdate = true;
    }

    // corrupted trees: dark twisted spikes
    const spikeGeo = mergeAll([
      new THREE.CylinderGeometry(0.12, 0.3, 3.4, 5).translate(0, 1.7, 0),
      new THREE.ConeGeometry(0.9, 2.8, 5).translate(0.3, 4.4, 0),
      new THREE.ConeGeometry(0.6, 2.0, 5).translate(-0.5, 3.6, 0.2),
    ])!;
    scatter(place(110, "corrupt", WORLD.WATER_LEVEL + 0.5, 20, avoidAll), spikeGeo,
      new THREE.MeshStandardMaterial({ color: 0x1d1426, roughness: 0.95, emissive: 0x2a0a44, emissiveIntensity: 0.35 }), 0.35);

    // rocks everywhere
    const rockGeo = new THREE.DodecahedronGeometry(1, 0);
    scatter(place(150, "any", WORLD.WATER_LEVEL, 80, avoidAll), rockGeo,
      new THREE.MeshStandardMaterial({ color: 0x77787c, roughness: 0.9 }), 0.9, 0.4);

    // glowing crystals in corrupted lands
    const crysGeo = new THREE.OctahedronGeometry(0.8, 0);
    const crysMat = new THREE.MeshStandardMaterial({
      color: 0x7a2ee8, emissive: 0x9a3cff, emissiveIntensity: 1.6, roughness: 0.2,
    });
    scatter(place(60, "corrupt", WORLD.WATER_LEVEL + 0.5, 20, avoidAll), crysGeo, crysMat, 0, 0.3);

    // grass tufts: instanced crossed quads with wind sway
    const tuft = mergeAll([
      new THREE.PlaneGeometry(0.4, 0.62).translate(0, 0.3, 0),
      new THREE.PlaneGeometry(0.4, 0.62).rotateY(Math.PI / 2).translate(0, 0.3, 0),
      new THREE.PlaneGeometry(0.34, 0.5).rotateY(Math.PI / 4).translate(0.08, 0.24, 0.05),
    ])!;
    const grassSpots = place(3400, "meadow", WORLD.WATER_LEVEL + 0.6, 10, avoidAll);
    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x74a94e, roughness: 0.9, side: THREE.DoubleSide,
    });
    grassMat.onBeforeCompile = (sh) => {
      sh.uniforms.uTime = { value: 0 };
      grassMat.userData.shader = sh;
      sh.vertexShader = "uniform float uTime;\n" + sh.vertexShader.replace(
        "#include <begin_vertex>",
        `#include <begin_vertex>
        #ifdef USE_INSTANCING
          vec2 ip = vec2(instanceMatrix[3][0], instanceMatrix[3][2]);
          transformed.x += sin(uTime * 2.1 + ip.x * 0.35 + ip.y * 0.27) * 0.12 * transformed.y;
        #endif`,
      );
    };
    this.grassMat = grassMat;
    const gm = new THREE.InstancedMesh(tuft, grassMat, grassSpots.length);
    for (let i = 0; i < grassSpots.length; i++) {
      const [x, h, z] = grassSpots[i];
      dummy.position.set(x, h - 0.05, z);
      dummy.rotation.set(0, rng() * Math.PI, 0);
      dummy.scale.setScalar(0.7 + rng() * 0.8);
      dummy.updateMatrix();
      gm.setMatrixAt(i, dummy.matrix);
    }
    gm.instanceMatrix.needsUpdate = true;
    gm.receiveShadow = true;
    this.group.add(gm);
  }

  private buildCastle(): void {
    const stone = new THREE.MeshStandardMaterial({ color: 0x8d8a82, roughness: 0.85 });
    const stoneDark = new THREE.MeshStandardMaterial({ color: 0x6e6b64, roughness: 0.9 });
    const parts: THREE.BufferGeometry[] = [];
    const rng = mulberry32(42);
    const base = terrainHeight(LAYOUT.castle.x, LAYOUT.castle.y);

    const addBox = (w: number, h: number, d: number, x: number, y: number, z: number, ry = 0) => {
      parts.push(new THREE.BoxGeometry(w, h, d).rotateY(ry).translate(x, y, z));
    };

    // broken curtain walls in a ring with gaps
    const R = 24;
    for (let i = 0; i < 18; i++) {
      if (rng() < 0.25) continue; // ruined gaps
      const a = (i / 18) * Math.PI * 2;
      const x = Math.cos(a) * R, z = Math.sin(a) * R;
      const h = 3 + rng() * 5;
      const y = terrainHeight(x, z);
      addBox(9, h, 1.6, x, y + h / 2 - 0.4, z, -a + Math.PI / 2);
      this.colliders.push({ x, z, r: 5.2 });
    }
    // towers
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const x = Math.cos(a) * R, z = Math.sin(a) * R;
      const y = terrainHeight(x, z);
      const th = 10 + rng() * 5;
      parts.push(new THREE.CylinderGeometry(2.6, 3.1, th, 8).translate(x, y + th / 2, z));
      parts.push(new THREE.ConeGeometry(3.2, 2.6, 8).translate(x, y + th + 1.2, z));
      this.colliders.push({ x, z, r: 3.4 });
    }
    // keep: broken great hall
    addBox(14, 9, 2, 0, base + 4.5, -10);
    addBox(2, 7, 12, -7, base + 3.5, -4);
    addBox(2, 5, 8, 7, base + 2.5, -5);
    this.colliders.push({ x: 0, z: -10, r: 8.5 }, { x: -7, z: -4, r: 3 }, { x: 7, z: -5, r: 3 });
    // fallen columns
    for (let i = 0; i < 7; i++) {
      const a = rng() * Math.PI * 2, r = 6 + rng() * 12;
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      parts.push(new THREE.CylinderGeometry(0.7, 0.7, 5 + rng() * 4, 7)
        .rotateZ(Math.PI / 2).rotateY(rng() * Math.PI)
        .translate(x, terrainHeight(x, z) + 0.7, z));
      this.colliders.push({ x, z, r: 2.2 });
    }
    // arches
    for (let i = 0; i < 3; i++) {
      const a = rng() * Math.PI * 2;
      const x = Math.cos(a) * 15, z = Math.sin(a) * 15;
      const y = terrainHeight(x, z);
      parts.push(new THREE.TorusGeometry(3.2, 0.7, 6, 10, Math.PI).translate(x, y + 0.6, z));
    }

    const merged = mergeAll(parts);
    const castle = new THREE.Mesh(merged, stone);
    castle.castShadow = true;
    castle.receiveShadow = true;
    this.group.add(castle);

    // braziers with warm lights (visible at night)
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      const x = Math.cos(a) * 12, z = Math.sin(a) * 12;
      const y = terrainHeight(x, z);
      const bowl = new THREE.Mesh(new THREE.CylinderGeometry(0.55, 0.3, 0.6, 8), stoneDark);
      bowl.position.set(x, y + 1.1, z);
      const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.16, 1.1, 6), stoneDark);
      pole.position.set(x, y + 0.55, z);
      const fire = new THREE.Mesh(
        new THREE.SphereGeometry(0.34, 8, 6),
        new THREE.MeshBasicMaterial({ color: 0xff9a33 }),
      );
      fire.position.set(x, y + 1.5, z);
      fire.name = "brazierFire";
      const l = new THREE.PointLight(0xff8830, 0, 18);
      l.position.set(x, y + 2, z);
      this.torchLights.push(l);
      this.group.add(bowl, pole, fire, l);
    }
  }

  private buildArena(): void {
    const obsidian = new THREE.MeshStandardMaterial({
      color: 0x17131f, roughness: 0.4, metalness: 0.3, emissive: 0x3a1060, emissiveIntensity: 0.4,
    });
    const parts: THREE.BufferGeometry[] = [];
    const cx = LAYOUT.bossArena.x, cz = LAYOUT.bossArena.y;
    for (let i = 0; i < 10; i++) {
      const a = (i / 10) * Math.PI * 2;
      const x = cx + Math.cos(a) * 24, z = cz + Math.sin(a) * 24;
      const h = 7 + (i % 3) * 2.5;
      const y = terrainHeight(x, z);
      parts.push(new THREE.ConeGeometry(1.6, h, 5).translate(x, y + h / 2 - 0.5, z));
      this.colliders.push({ x, z, r: 1.9 });
    }
    // spiky ground crystals around arena
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2 + 0.2;
      const r = 15 + (i % 4);
      const x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r;
      const h = 1.5 + (i % 3);
      parts.push(new THREE.ConeGeometry(0.6, h, 4).translate(x, terrainHeight(x, z) + h / 2 - 0.3, z));
    }
    const arena = new THREE.Mesh(mergeAll(parts), obsidian);
    arena.castShadow = true;
    arena.receiveShadow = true;
    this.group.add(arena);

    // the gate: two pillars + energy barrier on the west approach
    const gx = LAYOUT.bossArena.x - 26, gz = LAYOUT.bossArena.y;
    const gy = terrainHeight(gx, gz);
    const pillarGeo = new THREE.CylinderGeometry(0.9, 1.2, 8, 6);
    const p1 = new THREE.Mesh(pillarGeo, obsidian);
    p1.position.set(gx, gy + 4, gz - 5);
    const p2 = new THREE.Mesh(pillarGeo, obsidian);
    p2.position.set(gx, gy + 4, gz + 5);
    const barrier = new THREE.Mesh(
      new THREE.PlaneGeometry(10.4, 7.6),
      new THREE.MeshBasicMaterial({
        color: 0x8a3cff, transparent: true, opacity: 0.4, side: THREE.DoubleSide, depthWrite: false,
      }),
    );
    barrier.rotation.y = Math.PI / 2;
    barrier.position.set(gx, gy + 3.8, gz);
    barrier.name = "barrier";
    this.bossGate.add(p1, p2, barrier);
    this.bossGate.position.set(0, 0, 0);
    this.group.add(this.bossGate);
  }

  private buildShrine(id: number, rng: () => number): void {
    const s = LAYOUT.shrines[id];
    const y = terrainHeight(s.x, s.y);
    const stone = new THREE.MeshStandardMaterial({ color: 0x7d7a72, roughness: 0.85 });
    const g = new THREE.Group();
    g.position.set(s.x, y, s.y);
    // stone circle
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const m = new THREE.Mesh(new THREE.BoxGeometry(0.9, 2.2 + rng() * 0.8, 0.7), stone);
      m.position.set(Math.cos(a) * 3.4, 1, Math.sin(a) * 3.4);
      m.rotation.y = -a;
      m.castShadow = true;
      g.add(m);
      this.colliders.push({ x: s.x + Math.cos(a) * 3.4, z: s.y + Math.sin(a) * 3.4, r: 0.8 });
    }
    const plinth = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.4, 0.8, 8), stone);
    plinth.position.y = 0.4;
    g.add(plinth);
    const crystal = new THREE.Mesh(
      new THREE.OctahedronGeometry(0.7, 0),
      new THREE.MeshStandardMaterial({
        color: 0x33aaff, emissive: 0x2288ff, emissiveIntensity: 2.2, roughness: 0.15,
      }),
    );
    crystal.position.y = 2.2;
    g.add(crystal);
    const light = new THREE.PointLight(0x3388ff, 2.2, 20);
    light.position.y = 2.4;
    g.add(light);
    this.group.add(g);
    this.crystals.push(crystal);
    this.colliders.push({ x: s.x, z: s.y, r: 1.5 });
    this.shrines.push({
      id, pos: new THREE.Vector3(s.x, y, s.y), crystal, light, claimed: false,
    });
  }

  private buildChest(id: number, x: number, z: number): void {
    const y = terrainHeight(x, z);
    const g = new THREE.Group();
    g.position.set(x, y, z);
    const wood = new THREE.MeshStandardMaterial({ color: 0x6b4a2a, roughness: 0.8 });
    const trim = new THREE.MeshStandardMaterial({ color: 0xc9a54a, roughness: 0.4, metalness: 0.7 });
    const body = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.6, 0.7), wood);
    body.position.y = 0.3;
    body.castShadow = true;
    const lid = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.36, 1.1, 8, 1, false, 0, Math.PI), wood);
    lid.rotation.z = Math.PI / 2;
    lid.position.y = 0.6;
    const band = new THREE.Mesh(new THREE.BoxGeometry(1.14, 0.14, 0.74), trim);
    band.position.y = 0.42;
    g.add(body, lid, band);
    // golden glimmer
    const glow = new THREE.PointLight(0xffcc55, 0.7, 6);
    glow.position.y = 0.8;
    g.add(glow);
    this.group.add(g);
    this.chests.push({ id, pos: new THREE.Vector3(x, y, z), group: g, lid, opened: false });
  }

  // ------------------------------------------------------------ gameplay queries
  heightAt(x: number, z: number): number {
    return terrainHeight(x, z);
  }

  /** Push a circle (pos.x/z, radius) out of all colliders + soft world border. */
  collide(pos: THREE.Vector3, radius: number): void {
    for (const c of this.colliders) {
      const dx = pos.x - c.x, dz = pos.z - c.z;
      const rr = c.r + radius;
      const d2 = dx * dx + dz * dz;
      if (d2 < rr * rr && d2 > 1e-6) {
        const d = Math.sqrt(d2);
        const push = (rr - d) / d;
        pos.x += dx * push;
        pos.z += dz * push;
      }
    }
    // soft border: slide along the rim, never a hard invisible wall
    const r = Math.hypot(pos.x, pos.z);
    const max = HALF - 12;
    if (r > max) {
      const f = max / r;
      pos.x *= f;
      pos.z *= f;
    }
  }

  openBossGate(): void {
    this.bossGateOpen = true;
    const i = this.colliders.indexOf(this.bossGateCollider);
    if (i >= 0) this.colliders.splice(i, 1);
  }

  claimShrine(id: number): void {
    const s = this.shrines[id];
    if (!s || s.claimed) return;
    s.claimed = true;
    (s.crystal.material as THREE.MeshStandardMaterial).emissiveIntensity = 0.25;
    s.light.color.setHex(0x444444);
    s.light.intensity = 0.3;
  }

  openChest(id: number): void {
    const ch = this.chests[id];
    if (!ch || ch.opened) return;
    ch.opened = true;
    ch.lid.rotation.x = -1.1;
  }

  // ------------------------------------------------------------ simulation
  /** dt already scaled; playerPos keeps rain/stars/sky centred on the player. */
  update(dt: number, elapsed: number, playerPos: THREE.Vector3): void {
    this.time = (this.time + dt / this.dayLength) % 1;
    const ang = this.time * Math.PI * 2 - Math.PI / 2; // time 0.25 = sunrise (east)
    const sunEl = Math.sin(ang);
    const dayF = smooth(-0.14, 0.2, sunEl);
    const sunDir = new THREE.Vector3(Math.cos(ang) * 0.8, sunEl, Math.sin(ang) * 0.35).normalize();

    // sun + moon
    this.sun.position.copy(playerPos).addScaledVector(sunDir, 160);
    this.sun.target.position.copy(playerPos);
    const warm = smooth(0.0, 0.45, sunEl);
    this.sun.color.setRGB(1, 0.55 + warm * 0.4, 0.32 + warm * 0.6);
    this.sun.intensity = 2.7 * dayF * (1 - this.rainAmt * 0.55) * (1 - this.flash * 2);
    this.moon.position.copy(playerPos).addScaledVector(sunDir, -140);
    this.moon.target.position.copy(playerPos);
    this.moon.intensity = 0.35 * (1 - dayF);
    this.hemi.intensity = 0.18 + dayF * 0.75 * (1 - this.rainAmt * 0.4);

    // sky uniforms
    const su = this.skyMat.uniforms;
    (su.sunDir.value as THREE.Vector3).copy(sunDir);
    su.dayFactor.value = dayF;
    su.time.value = elapsed;
    // weather: cloud cover rises before rain
    su.cloudCover.value = 0.22 + this.rainAmt * 0.65;

    // stars fade in at night
    (this.stars.material as THREE.PointsMaterial).opacity = (1 - dayF) * 0.9;

    // water
    this.waterMat.uniforms.time.value = elapsed;
    this.waterMat.uniforms.dayFactor.value = dayF;
    (this.waterMat.uniforms.sunDir.value as THREE.Vector3).copy(sunDir);

    // braziers burn at night
    const night = 1 - dayF;
    for (const l of this.torchLights) l.intensity = night * 2.2;

    // crystals spin + bob
    for (let i = 0; i < this.crystals.length; i++) {
      const cr = this.crystals[i];
      cr.rotation.y = elapsed * 1.2 + i;
      cr.position.y = 2.2 + Math.sin(elapsed * 1.6 + i * 2) * 0.18;
    }

    // boss gate barrier shimmer
    if (this.gateBarrier) {
      const m = this.gateBarrier.material as THREE.MeshBasicMaterial;
      if (this.bossGateOpen) {
        m.opacity = Math.max(0, m.opacity - dt * 0.7);
        this.gateBarrier.visible = m.opacity > 0.01;
        this.gateLight.intensity = Math.max(0, this.gateLight.intensity - dt * 3);
      } else {
        m.opacity = 0.32 + Math.sin(elapsed * 3) * 0.1;
      }
    }

    // grass wind
    if (this.grassMat?.userData.shader) {
      this.grassMat.userData.shader.uniforms.uTime.value = elapsed;
    }

    // ---- weather machine
    this.weatherTimer -= dt;
    if (this.weatherTimer <= 0) {
      const roll = Math.random();
      if (this.rainTarget > 0.5) {
        this.rainTarget = 0;
        this.weatherTimer = 60 + Math.random() * 90;
      } else {
        this.rainTarget = roll < 0.4 ? 1 : 0;
        this.weatherTimer = this.rainTarget > 0 ? 35 + Math.random() * 40 : 50 + Math.random() * 80;
      }
    }
    this.rainAmt += (this.rainTarget - this.rainAmt) * Math.min(1, dt * 0.25);

    // rain follows the player, recycled in a box
    const rm = this.rain.material as THREE.PointsMaterial;
    if (this.rainAmt > 0.03) {
      this.rain.visible = true;
      rm.opacity = this.rainAmt * 0.55;
      const n = this.rainPos.length / 3;
      for (let i = 0; i < n; i++) {
        this.rainPos[i * 3 + 1] -= dt * 34;
        if (this.rainPos[i * 3 + 1] < 0) {
          this.rainPos[i * 3] = playerPos.x + (Math.random() - 0.5) * 60;
          this.rainPos[i * 3 + 1] = 20 + Math.random() * 8;
          this.rainPos[i * 3 + 2] = playerPos.z + (Math.random() - 0.5) * 60;
        }
      }
      (this.rain.geometry.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
      // lightning
      if (this.rainAmt > 0.6) {
        this.lightningTimer -= dt;
        if (this.lightningTimer <= 0) {
          this.lightningTimer = 5 + Math.random() * 12;
          this.flash = 0.5;
          this.onThunder?.();
        }
      }
    } else {
      this.rain.visible = false;
    }
    // lightning flash decay
    if (this.flash > 0) {
      this.flash = Math.max(0, this.flash - dt * 2.4);
      this.hemi.intensity += this.flash * 3;
    }
  }

  get raining(): boolean {
    return this.rainAmt > 0.5;
  }
  get dayFactor(): number {
    const sunEl = Math.sin(this.time * Math.PI * 2 - Math.PI / 2);
    return smooth(-0.14, 0.2, sunEl);
  }

  setQuality(low: boolean): void {
    this.sun.castShadow = !low;
    this.sun.shadow.mapSize.set(low ? 1024 : 2048, low ? 1024 : 2048);
    if (this.sun.shadow.map) {
      this.sun.shadow.map.dispose();
      this.sun.shadow.map = null;
    }
  }

  dispose(): void {
    this.group.traverse((o) => {
      const m = o as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = m.material as THREE.Material | THREE.Material[] | undefined;
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else if (mat) mat.dispose();
    });
  }
}
