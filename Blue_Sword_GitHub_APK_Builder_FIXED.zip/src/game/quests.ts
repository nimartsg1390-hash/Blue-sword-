/**
 * quests.ts — main quest chain (claim 3 Sigils from guarded shrines → the corrupted
 * gate opens → slay the Shadow Dragon), hidden chests, and interaction handling.
 */
import * as THREE from "three";
import { LAYOUT } from "./world";
import type { World } from "./world";
import type { Player } from "./player";
import type { EnemyManager } from "./enemies";
import type { FX } from "./effects";
import type { AudioSystem } from "./audio";

/** UI surface the quest system talks to (implemented by ui.ts). */
export interface HUD {
  setPrompt(text: string | null): void;
  toast(text: string, ms?: number): void;
  floatText(x: number, y: number, z: number, text: string, color: string): void;
  setQuest(text: string): void;
  showBossBar(name: string): void;
  setBossHp(frac: number): void;
  hideBossBar(): void;
}

const _v = new THREE.Vector3();

export class QuestSystem {
  sigilsClaimed: number[] = [];
  chestsOpened: number[] = [];
  bossDead = false;
  bossStarted = false;
  onVictory: (() => void) | null = null;

  constructor(
    private world: World,
    private player: Player,
    private enemies: EnemyManager,
    private fx: FX,
    private audio: AudioSystem,
    private hud: HUD,
  ) {
    this.refreshQuestText();
  }

  get questText(): string {
    if (this.bossDead) return "The realm is saved. Explore freely!";
    if (this.sigilsClaimed.length >= 3) return "Enter the corrupted gate and slay Vharzeth";
    return `Claim the Ancient Sigils  (${this.sigilsClaimed.length}/3)`;
  }

  private refreshQuestText(): void {
    this.hud.setQuest(this.questText);
  }

  /** Restore from a save. */
  applySave(sigils: number[], chests: number[], bossDead: boolean): void {
    for (const id of sigils) {
      this.world.claimShrine(id);
      this.sigilsClaimed.push(id);
    }
    for (const id of chests) this.world.openChest(id);
    this.chestsOpened = [...chests];
    this.bossDead = bossDead;
    if (sigils.length >= 3) this.world.openBossGate();
    this.refreshQuestText();
  }

  /** Nearest interactable + its prompt label. */
  private nearest(): { kind: "shrine" | "chest"; id: number; label: string; blocked?: string } | null {
    const p = this.player.pos;
    const R = 3.6;
    for (const s of this.world.shrines) {
      if (s.claimed) continue;
      if (Math.hypot(p.x - s.pos.x, p.z - s.pos.z) < R) {
        if (this.enemies.guardiansNear(s.pos.x, s.pos.z, 16)) {
          return { kind: "shrine", id: s.id, label: "Ancient Sigil", blocked: "Defeat the guardians first!" };
        }
        return { kind: "shrine", id: s.id, label: "Claim the Ancient Sigil" };
      }
    }
    for (const c of this.world.chests) {
      if (c.opened) continue;
      if (Math.hypot(p.x - c.pos.x, p.z - c.pos.z) < R) {
        return { kind: "chest", id: c.id, label: "Open the chest" };
      }
    }
    return null;
  }

  /** Called on interact press. Returns true if something was used. */
  interact(): boolean {
    const n = this.nearest();
    if (!n) return false;
    if (n.blocked) {
      this.hud.toast(n.blocked);
      this.audio.sfx("uiBack");
      return true;
    }
    if (n.kind === "shrine") {
      this.world.claimShrine(n.id);
      this.sigilsClaimed.push(n.id);
      this.audio.sfx("sigil");
      const s = this.world.shrines[n.id];
      this.fx.burst(s.pos.x, s.pos.y + 2.4, s.pos.z, 0x44aaff, 40, 7, 2.6, 1.1, 1);
      this.fx.shake(0.25);
      this.player.gainXp(150);
      this.hud.floatText(s.pos.x, s.pos.y + 3, s.pos.z, "+150 XP", "#6cf");
      if (this.sigilsClaimed.length >= 3) {
        this.world.openBossGate();
        this.hud.toast("The corrupted gate has opened!", 4200);
        this.audio.sfx("quest");
      } else {
        this.hud.toast(`Sigil claimed (${this.sigilsClaimed.length}/3)`);
      }
      this.refreshQuestText();
    } else {
      this.world.openChest(n.id);
      this.chestsOpened.push(n.id);
      this.audio.sfx("chest");
      const c = this.world.chests[n.id];
      this.fx.burst(c.pos.x, c.pos.y + 1, c.pos.z, 0xffcc44, 24, 5, 2, 0.8, 2);
      this.player.gainXp(60);
      this.player.heal(this.player.maxHp * 0.35);
      this.hud.floatText(c.pos.x, c.pos.y + 1.6, c.pos.z, "+60 XP  ·  Restored", "#fc6");
    }
    return true;
  }

  update(): void {
    // interact prompt
    const n = this.nearest();
    this.hud.setPrompt(n ? (n.blocked ? n.blocked : `[E] ${n.label}`) : null);

    // boss trigger
    if (!this.bossStarted && !this.bossDead && this.world.bossGateOpen && !this.enemies.boss.active) {
      const a = LAYOUT.bossArena;
      if (Math.hypot(this.player.pos.x - a.x, this.player.pos.z - a.y) < 30) {
        this.bossStarted = true;
        this.enemies.boss.activate();
        this.hud.showBossBar("Vharzeth, the Shadow Dragon");
        this.audio.sfx("bossRoar");
        this.hud.toast("Vharzeth awakens!", 3000);
      }
    }
    // boss bar + victory
    const b = this.enemies.boss;
    if (this.bossStarted && b.active && !b.dead) {
      this.hud.setBossHp(Math.max(0, b.hp / b.maxHp));
    }
    if (this.bossStarted && b.dead && !this.bossDead) {
      this.bossDead = true;
      this.hud.hideBossBar();
      this.player.gainXp(600);
      this.audio.sfx("victory");
      this.refreshQuestText();
      this.onVictory?.();
    }
  }
}
