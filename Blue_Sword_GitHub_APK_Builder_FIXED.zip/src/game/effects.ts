/**
 * effects.ts — pooled GPU point particles, sword trail ribbon, screen shake, hit-stop.
 * Zero per-frame allocation: fixed-capacity buffers, CPU-simulated, single draw call.
 */
import * as THREE from "three";
import { QUALITY } from "./config";

const MAX_PARTICLES = 600;
const TRAIL_SEGS = 14;

interface Particle {
  alive: boolean;
  px: number; py: number; pz: number;
  vx: number; vy: number; vz: number;
  life: number; maxLife: number;
  size: number; r: number; g: number; b: number;
  gravity: number; drag: number;
}

export class FX {
  readonly group = new THREE.Group();
  private particles: Particle[] = [];
  private points: THREE.Points;
  private posAttr: THREE.BufferAttribute;
  private colAttr: THREE.BufferAttribute;
  private sizeAttr: THREE.BufferAttribute;
  private budget: number = QUALITY.PARTICLES_HIGH;

  // sword trail
  private trailGeom: THREE.BufferGeometry;
  private trailPos: Float32Array;
  private trailAlpha: Float32Array;
  private trailMesh: THREE.Mesh;
  private trailHistory: THREE.Vector3[] = [];
  private trailOn = false;

  // screen shake / hit-stop
  trauma = 0;
  hitStopT = 0;
  timeScale = 1;
  camShakeEnabled = true;

  private tmpColor = new THREE.Color();

  constructor() {
    for (let i = 0; i < MAX_PARTICLES; i++) {
      this.particles.push({
        alive: false, px: 0, py: 0, pz: 0, vx: 0, vy: 0, vz: 0,
        life: 0, maxLife: 1, size: 1, r: 1, g: 1, b: 1, gravity: 0, drag: 0,
      });
    }
    const geom = new THREE.BufferGeometry();
    this.posAttr = new THREE.BufferAttribute(new Float32Array(MAX_PARTICLES * 3), 3);
    this.colAttr = new THREE.BufferAttribute(new Float32Array(MAX_PARTICLES * 3), 3);
    this.sizeAttr = new THREE.BufferAttribute(new Float32Array(MAX_PARTICLES), 1);
    this.posAttr.setUsage(THREE.DynamicDrawUsage);
    this.colAttr.setUsage(THREE.DynamicDrawUsage);
    this.sizeAttr.setUsage(THREE.DynamicDrawUsage);
    geom.setAttribute("position", this.posAttr);
    geom.setAttribute("color", this.colAttr);
    geom.setAttribute("psize", this.sizeAttr);
    const mat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute float psize;
        varying vec3 vColor;
        void main() {
          vColor = color;
          vec4 mv = modelViewMatrix * vec4(position, 1.0);
          gl_PointSize = psize * (180.0 / -mv.z);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec3 vColor;
        void main() {
          vec2 d = gl_PointCoord - 0.5;
          float a = smoothstep(0.5, 0.05, length(d));
          gl_FragColor = vec4(vColor, a);
        }`,
      vertexColors: true,
    });
    this.points = new THREE.Points(geom, mat);
    this.points.frustumCulled = false;
    this.group.add(this.points);

    // trail ribbon: 2 verts per segment
    this.trailPos = new Float32Array(TRAIL_SEGS * 2 * 3);
    this.trailAlpha = new Float32Array(TRAIL_SEGS * 2);
    this.trailGeom = new THREE.BufferGeometry();
    const tp = new THREE.BufferAttribute(this.trailPos, 3);
    tp.setUsage(THREE.DynamicDrawUsage);
    const ta = new THREE.BufferAttribute(this.trailAlpha, 1);
    ta.setUsage(THREE.DynamicDrawUsage);
    this.trailGeom.setAttribute("position", tp);
    this.trailGeom.setAttribute("alpha", ta);
    const trailMat = new THREE.ShaderMaterial({
      transparent: true,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      vertexShader: `
        attribute float alpha;
        varying float vA;
        void main() { vA = alpha; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `
        varying float vA;
        void main() { gl_FragColor = vec4(0.35, 0.65, 1.0, vA * 0.75); }`,
    });
    this.trailMesh = new THREE.Mesh(this.trailGeom, trailMat);
    this.trailMesh.frustumCulled = false;
    this.trailMesh.visible = false;
    this.group.add(this.trailMesh);
    for (let i = 0; i < TRAIL_SEGS; i++) this.trailHistory.push(new THREE.Vector3());
  }

  setBudget(low: boolean): void {
    this.budget = low ? QUALITY.PARTICLES_LOW : QUALITY.PARTICLES_HIGH;
  }

  /** Spawn n particles at (x,y,z). */
  burst(x: number, y: number, z: number, color: number, count: number, speed = 5, size = 1.6, life = 0.6, gravity = 6, up = 2): void {
    this.tmpColor.setHex(color);
    let spawned = 0;
    for (const p of this.particles) {
      if (spawned >= count) break;
      if (p.alive) continue;
      p.alive = true;
      p.px = x; p.py = y; p.pz = z;
      const a = Math.random() * Math.PI * 2;
      const r = (0.3 + Math.random() * 0.7) * speed;
      p.vx = Math.cos(a) * r;
      p.vz = Math.sin(a) * r;
      p.vy = up * (0.4 + Math.random());
      p.maxLife = life * (0.6 + Math.random() * 0.7);
      p.life = p.maxLife;
      p.size = size * (0.6 + Math.random() * 0.8);
      p.r = this.tmpColor.r; p.g = this.tmpColor.g; p.b = this.tmpColor.b;
      p.gravity = gravity;
      p.drag = 2.2;
      spawned++;
    }
  }

  shake(amount: number): void {
    if (this.camShakeEnabled) this.trauma = Math.min(1, this.trauma + amount);
  }
  hitStop(dur: number): void {
    this.hitStopT = Math.max(this.hitStopT, dur);
  }

  /** Begin/extend the sword trail; supply blade base and tip world positions each frame while active. */
  updateTrail(active: boolean, base: THREE.Vector3, tip: THREE.Vector3): void {
    this.trailOn = active;
    if (active) {
      this.trailHistory.pop();
      this.trailHistory.unshift(tip.clone());
      // base positions derived from history, offset perpendicular for ribbon width
      const n = this.trailHistory.length;
      for (let i = 0; i < n; i++) {
        const h = this.trailHistory[i];
        const t = i / (n - 1);
        const b = this.tmpBase.copy(base).lerp(this.trailHistory[Math.min(i, n - 1)], 0); // fallback
        // ribbon: one edge at blade line, other edge slightly behind
        this.trailPos[i * 6 + 0] = h.x;
        this.trailPos[i * 6 + 1] = h.y;
        this.trailPos[i * 6 + 2] = h.z;
        this.trailPos[i * 6 + 3] = h.x + (h.x - b.x) * 0.12 - 0.05;
        this.trailPos[i * 6 + 4] = h.y + 0.02;
        this.trailPos[i * 6 + 5] = h.z + (h.z - b.z) * 0.12 - 0.05;
        const a = (1 - t) * 0.9;
        this.trailAlpha[i * 2] = a;
        this.trailAlpha[i * 2 + 1] = a * 0.4;
      }
      (this.trailGeom.getAttribute("position") as THREE.BufferAttribute).needsUpdate = true;
      (this.trailGeom.getAttribute("alpha") as THREE.BufferAttribute).needsUpdate = true;
      // build index once
      if (!this.trailGeom.index) {
        const idx: number[] = [];
        for (let i = 0; i < n - 1; i++) {
          const a = i * 2, b2 = i * 2 + 1, c = i * 2 + 2, d = i * 2 + 3;
          idx.push(a, b2, c, b2, d, c);
        }
        this.trailGeom.setIndex(idx);
      }
      this.trailMesh.visible = true;
    } else {
      this.trailMesh.visible = false;
      for (const h of this.trailHistory) h.copy(tip);
    }
  }
  private tmpBase = new THREE.Vector3();

  update(dt: number): void {
    // hit-stop decays back to normal timescale
    if (this.hitStopT > 0) {
      this.hitStopT -= dt;
      this.timeScale = 0.12;
    } else {
      this.timeScale = Math.min(1, this.timeScale + dt * 6);
    }
    this.trauma = Math.max(0, this.trauma - dt * 1.6);

    const pos = this.posAttr.array as Float32Array;
    const col = this.colAttr.array as Float32Array;
    const siz = this.sizeAttr.array as Float32Array;
    let active = 0;
    for (let i = 0; i < MAX_PARTICLES; i++) {
      const p = this.particles[i];
      if (!p.alive) { siz[i] = 0; continue; }
      p.life -= dt;
      if (p.life <= 0) { p.alive = false; siz[i] = 0; continue; }
      const dragF = 1 - Math.min(0.9, p.drag * dt);
      p.vx *= dragF; p.vz *= dragF;
      p.vy = p.vy * dragF - p.gravity * dt;
      p.px += p.vx * dt;
      p.py += p.vy * dt;
      p.pz += p.vz * dt;
      const fade = p.life / p.maxLife;
      pos[i * 3] = p.px; pos[i * 3 + 1] = p.py; pos[i * 3 + 2] = p.pz;
      col[i * 3] = p.r * fade; col[i * 3 + 1] = p.g * fade; col[i * 3 + 2] = p.b * fade;
      siz[i] = p.size * (0.4 + fade * 0.6);
      active++;
    }
    this.posAttr.needsUpdate = true;
    this.colAttr.needsUpdate = true;
    this.sizeAttr.needsUpdate = true;
    this.activeParticles = active;
  }

  activeParticles = 0;

  dispose(): void {
    this.points.geometry.dispose();
    (this.points.material as THREE.Material).dispose();
    this.trailGeom.dispose();
    (this.trailMesh.material as THREE.Material).dispose();
  }
}
