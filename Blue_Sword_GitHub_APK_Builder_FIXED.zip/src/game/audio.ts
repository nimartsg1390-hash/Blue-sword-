/**
 * audio.ts — Web Audio synthesized SFX + adaptive layered music. No audio asset files:
 * everything is generated at runtime. Music has intensity layers (explore / combat / boss)
 * crossfaded by game state; SFX are short enveloped oscillator/noise bursts.
 */

export type SfxId =
  | "attack" | "heavy" | "hit" | "hurt" | "block" | "roll" | "step"
  | "pickup" | "chest" | "levelup" | "sigil" | "quest"
  | "enemyDie" | "bossRoar" | "fire" | "thunder"
  | "ui" | "uiBack" | "victory" | "lose" | "shrine";

const MUTE_KEY = "game.muted";

function readMuted(): boolean {
  try { return localStorage.getItem(MUTE_KEY) === "1"; } catch { return false; }
}
function writeMuted(v: boolean): void {
  try { localStorage.setItem(MUTE_KEY, v ? "1" : "0"); } catch { /* ignore */ }
}

export class AudioSystem {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private disposed = false;
  muted = false;

  private musicTimer = 0;
  private musicStep = 0;
  private intensity = 0;
  private targetIntensity = 0;

  private readonly unlock = () => { this.ensureCtx(); this.detachUnlock(); };

  constructor() {
    this.muted = readMuted();
    window.addEventListener("pointerdown", this.unlock);
    window.addEventListener("keydown", this.unlock);
  }

  private detachUnlock(): void {
    window.removeEventListener("pointerdown", this.unlock);
    window.removeEventListener("keydown", this.unlock);
  }

  dispose(): void {
    if (this.disposed) return;
    this.disposed = true;
    this.detachUnlock();
    this.stopMusic();
    this.master?.disconnect();
    this.master = null;
    const ctx = this.ctx;
    this.ctx = null;
    if (ctx && ctx.state !== "closed") void ctx.close();
  }

  private ensureCtx(): AudioContext {
    if (!this.ctx) {
      this.ctx = new AudioContext();
      this.master = this.ctx.createGain();
      this.master.gain.value = this.muted ? 0 : 0.55;
      this.master.connect(this.ctx.destination);
      this.musicBus = this.ctx.createGain();
      this.musicBus.gain.value = 0.5;
      this.musicBus.connect(this.master);
      this.sfxBus = this.ctx.createGain();
      this.sfxBus.gain.value = 0.9;
      this.sfxBus.connect(this.master);
    }
    if (this.ctx.state === "suspended") void this.ctx.resume();
    return this.ctx;
  }

  toggleMute(): boolean {
    this.muted = !this.muted;
    writeMuted(this.muted);
    if (this.master) this.master.gain.value = this.muted ? 0 : 0.55;
    return this.muted;
  }
  setMuted(v: boolean): void {
    if (this.muted !== v) this.toggleMute();
  }

  /** Update music; call every frame. */
  update(dt: number): void {
    if (this.disposed || !this.ctx || this.muted) return;
    this.intensity += (this.targetIntensity - this.intensity) * Math.min(1, dt * 1.2);
    this.musicTimer -= dt;
    if (this.musicTimer <= 0) {
      this.scheduleMusicStep();
      this.musicTimer = 0.24; // 8th notes at ~125bpm grid
    }
  }

  setMusic(mode: "off" | "title" | "explore" | "combat" | "boss"): void {
    this.targetIntensity = { off: 0, title: 0.12, explore: 0.3, combat: 0.65, boss: 1 }[mode];
  }

  stopMusic(): void {
    this.targetIntensity = 0;
    this.intensity = 0;
  }

  // ---- music: chord pad + bass + percussion, density scales with intensity ----
  private static readonly CHORDS: number[][] = [
    [110.0, 130.81, 164.81],  // Am
    [87.31, 130.81, 174.61],  // F
    [98.0, 146.83, 196.0],    // G... (relative voicings)
    [82.41, 123.47, 164.81],  // E-ish tension
  ];
  private static readonly BOSS_CHORDS: number[][] = [
    [73.42, 110.0, 146.83],   // D dark
    [69.3, 103.83, 138.59],   // C# dim color
    [82.41, 123.47, 164.81],
    [73.42, 116.54, 146.83],
  ];

  private scheduleMusicStep(): void {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const t = ctx.currentTime;
    const step = this.musicStep++;
    const bar = Math.floor(step / 16) % 4;
    const inBar = step % 16;
    const boss = this.targetIntensity >= 0.9;
    const chords = boss ? AudioSystem.BOSS_CHORDS : AudioSystem.CHORDS;
    const chord = chords[bar];

    // pad: retrigger each bar
    if (inBar === 0) {
      for (const f of chord) {
        this.tone(t, f, 3.9, "sawtooth", 0.028 + this.intensity * 0.012, 500, this.musicBus);
        this.tone(t, f * 2.003, 3.9, "triangle", 0.02, 900, this.musicBus);
      }
    }
    // bass pulse
    if (this.intensity > 0.2 && inBar % 4 === 0) {
      this.tone(t, chord[0] / 2, 0.22, "square", 0.05 + this.intensity * 0.05, 300, this.musicBus);
    }
    // percussion enters with combat intensity
    if (this.intensity > 0.45) {
      if (inBar % 4 === 0) this.kick(t);
      if (inBar % 4 === 2) this.noiseHit(t, 0.05, 3500, 0.03 + this.intensity * 0.03);
      if (boss && inBar % 2 === 1) this.noiseHit(t, 0.03, 6000, 0.025);
    }
    // sparkle arp at low intensity (explore)
    if (this.intensity > 0.15 && this.intensity < 0.55 && inBar % 8 === 4) {
      this.tone(t, chord[(step / 8) % 3 | 0] * 4, 0.5, "sine", 0.035, 3000, this.musicBus);
    }
  }

  private tone(t: number, freq: number, dur: number, type: OscillatorType, gain: number, cutoff: number, bus: GainNode): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    const lp = ctx.createBiquadFilter();
    lp.type = "lowpass";
    lp.frequency.value = cutoff;
    osc.type = type;
    osc.frequency.value = freq;
    g.gain.setValueAtTime(0, t);
    g.gain.linearRampToValueAtTime(gain, t + 0.08);
    g.gain.setValueAtTime(gain, t + dur - 0.4);
    g.gain.linearRampToValueAtTime(0, t + dur);
    osc.connect(lp).connect(g).connect(bus);
    osc.start(t);
    osc.stop(t + dur + 0.05);
  }

  private kick(t: number): void {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(120, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.12);
    g.gain.setValueAtTime(0.32, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + 0.16);
    osc.connect(g).connect(this.musicBus);
    osc.start(t);
    osc.stop(t + 0.2);
  }

  private noiseHit(t: number, dur: number, cutoff: number, gain: number): void {
    const ctx = this.ctx;
    if (!ctx || !this.musicBus) return;
    const buf = this.noiseBuffer();
    if (!buf) return;
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const lp = ctx.createBiquadFilter();
    lp.type = "highpass";
    lp.frequency.value = cutoff;
    const g = ctx.createGain();
    g.gain.setValueAtTime(gain, t);
    g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    src.connect(lp).connect(g).connect(this.musicBus);
    src.start(t, Math.random() * 0.5);
    src.stop(t + dur + 0.02);
  }

  private noiseBuf: AudioBuffer | null = null;
  private noiseBuffer(): AudioBuffer | null {
    const ctx = this.ctx;
    if (!ctx) return null;
    if (!this.noiseBuf) {
      const len = ctx.sampleRate;
      this.noiseBuf = ctx.createBuffer(1, len, ctx.sampleRate);
      const d = this.noiseBuf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    }
    return this.noiseBuf;
  }

  // ---- SFX ----
  sfx(id: SfxId): void {
    if (this.disposed || this.muted) return;
    const ctx = this.ensureCtx();
    if (!this.sfxBus) return;
    const t = ctx.currentTime;
    const tone = (type: OscillatorType, f0: number, f1: number, dur: number, gain: number, cutoff = 4000) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      const lp = ctx.createBiquadFilter();
      lp.type = "lowpass";
      lp.frequency.value = cutoff;
      osc.type = type;
      osc.frequency.setValueAtTime(Math.max(1, f0), t);
      osc.frequency.exponentialRampToValueAtTime(Math.max(1, f1), t + dur);
      g.gain.setValueAtTime(gain, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      osc.connect(lp).connect(g).connect(this.sfxBus!);
      osc.start(t);
      osc.stop(t + dur + 0.02);
    };
    const noise = (dur: number, cutoff: number, gain: number, type: BiquadFilterType = "bandpass") => {
      const buf = this.noiseBuffer();
      if (!buf) return;
      const src = ctx.createBufferSource();
      src.buffer = buf;
      const f = ctx.createBiquadFilter();
      f.type = type;
      f.frequency.value = cutoff;
      const g = ctx.createGain();
      g.gain.setValueAtTime(gain, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + dur);
      src.connect(f).connect(g).connect(this.sfxBus!);
      src.start(t, Math.random() * 0.4);
      src.stop(t + dur + 0.02);
    };

    switch (id) {
      case "attack": noise(0.16, 2600, 0.22, "highpass"); tone("sine", 320, 140, 0.1, 0.08); break;
      case "heavy": noise(0.3, 1600, 0.3, "highpass"); tone("sine", 180, 60, 0.28, 0.16); break;
      case "hit": tone("square", 190, 70, 0.1, 0.22, 1800); noise(0.08, 900, 0.2); break;
      case "hurt": tone("sawtooth", 220, 90, 0.22, 0.22, 1200); break;
      case "block": tone("square", 620, 380, 0.09, 0.16, 3000); noise(0.06, 2400, 0.14, "highpass"); break;
      case "roll": noise(0.22, 700, 0.14, "lowpass"); break;
      case "step": noise(0.05, 500, 0.05, "lowpass"); break;
      case "pickup": tone("sine", 660, 990, 0.14, 0.18); tone("sine", 990, 1320, 0.12, 0.1); break;
      case "chest": tone("sine", 392, 784, 0.3, 0.16); tone("sine", 523, 1046, 0.34, 0.12); break;
      case "levelup": [523, 659, 784, 1046].forEach((f, i) => tone("triangle", f, f, 0.32, 0.14)); break;
      case "sigil": tone("sine", 220, 880, 0.6, 0.18); tone("sine", 330, 1320, 0.7, 0.1); break;
      case "quest": tone("triangle", 587, 587, 0.2, 0.14); tone("triangle", 880, 880, 0.3, 0.12); break;
      case "enemyDie": tone("sawtooth", 160, 40, 0.4, 0.2, 900); noise(0.3, 500, 0.16, "lowpass"); break;
      case "bossRoar": tone("sawtooth", 90, 45, 1.0, 0.3, 700); noise(0.8, 300, 0.22, "lowpass"); break;
      case "fire": noise(0.5, 1200, 0.16, "lowpass"); break;
      case "thunder": noise(1.2, 200, 0.4, "lowpass"); tone("sine", 60, 30, 1.0, 0.24); break;
      case "ui": tone("sine", 520, 640, 0.06, 0.1); break;
      case "uiBack": tone("sine", 440, 330, 0.08, 0.1); break;
      case "victory": [523, 659, 784, 1046, 1318].forEach((f) => tone("triangle", f, f, 0.5, 0.14)); break;
      case "lose": tone("sawtooth", 196, 49, 1.2, 0.2, 800); break;
      case "shrine": tone("sine", 440, 880, 0.8, 0.12); break;
    }
  }
}
