/**
 * save.ts — localStorage persistence for the run (position, level, sigils, chests, upgrades,
 * playtime) and for settings. Browser-local: doesn't sync across devices; clearing browser
 * data loses it. All access is defensive — a game must never fail to start because storage is blocked.
 */
import { SAVE_KEY, SETTINGS_KEY } from "./config";

export interface RunSave {
  version: 1;
  pos: [number, number, number];
  hp: number;
  level: number;
  xp: number;
  statPoints: number;
  stats: { vigor: number; endurance: number; strength: number };
  sigils: number[];
  chests: number[];
  bossDead: boolean;
  playtime: number;
  kills: number;
}

export interface Settings {
  quality: "auto" | "high" | "low";
  sensX: number;       // 0.4..2.0 multiplier
  sensY: number;
  invertX: boolean;
  invertY: boolean;
  muted: boolean;
  btnScale: number;    // 0.8..1.6
  leftHanded: boolean;
  camShake: boolean;
}

export const DEFAULT_SETTINGS: Settings = {
  quality: "auto",
  sensX: 1,
  sensY: 1,
  invertX: false,
  invertY: false,
  muted: false,
  btnScale: 1,
  leftHanded: false,
  camShake: true,
};

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw === null) return fallback;
    return { ...fallback, ...(JSON.parse(raw) as T) };
  } catch {
    return fallback;
  }
}

function write(key: string, value: unknown): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // storage full / private mode — in-memory state still works
  }
}

export const save = {
  loadRun(): RunSave | null {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return null;
      const parsed = JSON.parse(raw) as RunSave;
      return parsed.version === 1 ? parsed : null;
    } catch {
      return null;
    }
  },
  writeRun(run: RunSave): void {
    write(SAVE_KEY, run);
  },
  clearRun(): void {
    try {
      localStorage.removeItem(SAVE_KEY);
    } catch {
      /* ignore */
    }
  },
  hasRun(): boolean {
    try {
      return localStorage.getItem(SAVE_KEY) !== null;
    } catch {
      return false;
    }
  },
  loadSettings(): Settings {
    return read<Settings>(SETTINGS_KEY, DEFAULT_SETTINGS);
  },
  writeSettings(s: Settings): void {
    write(SETTINGS_KEY, s);
  },
};
