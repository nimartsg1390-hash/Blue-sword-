/**
 * boot.ts — session entry: renderer + scene + all systems, the fixed-timestep loop,
 * state machine transitions, saving, settings, quality scaling, and the verification
 * hooks (__GAME_READY__, __gameProbe).
 */
import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { GameLoop } from "./engine";
import { GameStateMachine } from "./state";
import { Input } from "./input";
import { AudioSystem } from "./audio";
import { World, LAYOUT } from "./world";
import { FX } from "./effects";
import { Player } from "./player";
import { EnemyManager } from "./enemies";
import { QuestSystem } from "./quests";
import { GameUI, type UIHandlers } from "./ui";
import { save, type Settings, type RunSave } from "./save";
import { QUALITY, XP_CURVE } from "./config";

export interface GameSession {
  dispose(): void;
}

declare global {
  interface Window {
    __GAME_READY__?: boolean;
    __gameProbe?: () => { x: number; y: number; z: number };
    __debug?: Record<string, (...args: number[]) => unknown>;
  }
}

let session: GameSession | null = null;

export function startGame(canvas: HTMLCanvasElement): GameSession {
  stopGame();
  const s = createSession(canvas);
  session = s;
  return s;
}

export function stopGame(): void {
  session?.dispose();
  session = null;
}

function createSession(canvas: HTMLCanvasElement): GameSession {
  // ---------- renderer / scene / camera
  const renderer = new THREE.WebGLRenderer({
    canvas,
    antialias: true,
    preserveDrawingBuffer: true,
    powerPreference: "high-performance",
  });
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  // production: skip three's diagnostic program validation (spurious VALIDATE_STATUS
  // failures on software GL drivers would otherwise spam console errors)
  renderer.debug.checkShaderErrors = false;
  let pixelRatioCap = 1.75;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, pixelRatioCap));
  renderer.setSize(window.innerWidth, window.innerHeight, false);

  const scene = new THREE.Scene();
  scene.fog = new THREE.Fog(0x9db4cc, 90, 520);
  // image-based ambient so metals/cloth read correctly (no black-armor look)
  {
    const pmrem = new THREE.PMREMGenerator(renderer);
    scene.environment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environmentIntensity = 0.45;
    pmrem.dispose();
  }
  const camera = new THREE.PerspectiveCamera(62, window.innerWidth / window.innerHeight, 0.1, 1200);
  camera.position.set(0, 20, 40);

  // ---------- settings
  let settings: Settings = save.loadSettings();
  const applySettings = () => {
    input.sensX = settings.sensX;
    input.sensY = settings.sensY;
    input.invertX = settings.invertX;
    input.invertY = settings.invertY;
    input.leftHanded = settings.leftHanded;
    fx.camShakeEnabled = settings.camShake;
    ui.applyControlSettings(settings.btnScale, settings.leftHanded);
    audio.setMuted(settings.muted);
    ui.setMuted(settings.muted);
    if (settings.quality === "high") setTier(false);
    else if (settings.quality === "low") setTier(true);
  };

  // ---------- systems
  const input = new Input(canvas);
  const audio = new AudioSystem();
  const world = new World();
  scene.add(world.group);
  const fx = new FX();
  scene.add(fx.group);
  const player = new Player();
  scene.add(player.rig.group);
  const enemies = new EnemyManager(scene, world, fx, audio);
  const state = new GameStateMachine();

  let kills = 0;
  let playtime = 0;
  let ui!: GameUI;

  const writeSave = (): void => {
    if (state.is("title")) return;
    const run: RunSave = {
      version: 1,
      pos: [player.pos.x, player.pos.y, player.pos.z],
      hp: player.hp,
      level: player.level, xp: player.xp, statPoints: player.statPoints,
      stats: { ...player.stats },
      sigils: [...quests.sigilsClaimed],
      chests: [...quests.chestsOpened],
      bossDead: quests.bossDead,
      playtime, kills,
    };
    save.writeRun(run);
  };

  // ---------- UI
  const handlers: UIHandlers = {
    hasSave: () => save.hasRun(),
    saveSummary: () => {
      const r = save.loadRun();
      return r ? `Lv ${r.level} · ${r.sigils.length}/3 sigils` : "";
    },
    newGame: () => {
      save.clearRun();
      bootInto("new");
    },
    continueGame: () => bootInto("continue"),
    resume: () => {
      if (state.is("paused", "victory")) {
        state.transition("playing");
        ui.show("none");
      }
    },
    quitToTitle: () => {
      writeSave();
      bootInto("title");
    },
    respawn: () => {
      // rise at the castle, keep progress
      player.spawnAt(LAYOUT.spawn.x, LAYOUT.spawn.y, LAYOUT.spawn.z);
      enemies.boss.reset();
      if (quests.bossStarted && !quests.bossDead) {
        quests.bossStarted = false;
        ui.hideBossBar();
      }
      state.transition("playing");
      ui.show("none");
      audio.setMusic("explore");
      writeSave();
    },
    spendPoint: (stat) => {
      if (player.statPoints <= 0) return;
      player.statPoints--;
      player.stats[stat]++;
      player.applyStats();
      audio.sfx("ui");
      writeSave();
    },
    getStats: () => ({
      level: player.level,
      statPoints: player.statPoints,
      stats: player.stats,
      xp: player.xp,
      xpNeed: XP_CURVE(player.level),
    }),
    getSettings: () => settings,
    updateSettings: (patch) => {
      settings = { ...settings, ...patch };
      save.writeSettings(settings);
      applySettings();
    },
    toggleMute: () => {
      const m = audio.toggleMute();
      settings = { ...settings, muted: m };
      save.writeSettings(settings);
      ui.setMuted(m);
      return m;
    },
  };
  ui = new GameUI(document.getElementById("ui-overlay") as HTMLElement, handlers);
  ui.setCamera(camera);

  // ---------- quests
  const quests = new QuestSystem(world, player, enemies, fx, audio, ui);
  quests.onVictory = () => {
    writeSave();
    setTimeout(() => {
      if (state.is("playing")) {
        state.transition("victory");
        ui.showVictory(player.level, kills, playtime);
        audio.setMusic("title");
      }
    }, 2200);
  };

  // kill feed
  enemies.onKill = (xp, x, y, z) => {
    kills++;
    const leveled = player.gainXp(xp);
    ui.floatText(x, y + 0.6, z, `+${xp} XP`, "#8cf");
    audio.sfx("pickup");
    if (leveled) {
      ui.toast(`Level up! You are now level ${player.level}. Stat point earned — spend it in the pause menu.`, 3600);
      audio.sfx("levelup");
      fx.burst(player.pos.x, player.pos.y + 1.5, player.pos.z, 0x66ffcc, 30, 6, 2.4, 1, 1);
    }
  };

  player.onDeath = () => {
    writeSave();
    setTimeout(() => {
      if (state.is("playing")) {
        state.transition("gameover");
        ui.showGameOver(player.level, kills, playtime);
        audio.setMusic("off");
      }
    }, 1600);
  };

  // player hurt flash: small blood vignette via HUD hp bar is enough; camera shake handled in fx.

  world.onThunder = () => {
    audio.sfx("thunder");
    fx.shake(0.25);
  };

  // ---------- quality tiers
  let lowTier = false;
  let fpsAccum = 0, fpsFrames = 0, fpsTimer = 0;
  function setTier(low: boolean): void {
    if (lowTier === low) return;
    lowTier = low;
    world.setQuality(low);
    fx.setBudget(low);
    pixelRatioCap = low ? 1.2 : 1.75;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, pixelRatioCap));
  }

  // ---------- session boot modes
  let titleOrbit = 0;
  /** True once a run has started — a fresh world is needed to reset properly. */
  let dirty = false;

  function startPlaying(): void {
    if (state.is("title")) state.transition("playing");
    ui.show("none");
    audio.setMusic("explore");
    dirty = true;
  }

  function bootInto(mode: "new" | "continue" | "title"): void {
    if (mode === "new") {
      save.clearRun();
      if (!dirty && state.is("title")) {
        // pristine session — start immediately
        player.spawnAt(LAYOUT.spawn.x, LAYOUT.spawn.y, LAYOUT.spawn.z);
        startPlaying();
      } else {
        // a run already touched this world — rebuild a pristine session and start it
        restartInto(canvas, "new");
      }
      return;
    }
    if (mode === "continue") {
      const r = save.loadRun();
      if (!r || dirty) {
        // rebuild so the world matches the save exactly
        restartInto(canvas, r ? "continue" : "new");
        return;
      }
      player.level = r.level; player.xp = r.xp; player.statPoints = r.statPoints;
      player.stats = { ...r.stats };
      player.applyStats();
      kills = r.kills; playtime = r.playtime;
      player.spawnAt(r.pos[0], r.pos[1], r.pos[2]);
      player.hp = Math.max(1, Math.min(r.hp, player.maxHp));
      quests.applySave(r.sigils, r.chests, r.bossDead);
      startPlaying();
      ui.toast("Welcome back, knight.", 2200);
      return;
    }
    // title
    if (dirty) {
      restartInto(canvas, "title");
      return;
    }
    state.transition("title");
    ui.show("title");
    audio.setMusic("title");
  }

  // ---------- pointer lock (desktop)
  canvas.addEventListener("click", () => {
    if (state.is("playing") && !input.usingTouch && document.pointerLockElement !== canvas) {
      canvas.requestPointerLock?.();
    }
  });

  // ---------- compass markers
  ui.setMarker(0, () => {
    for (const s of world.shrines) if (!s.claimed) return s.pos;
    return null;
  }, "◆", "mk-sigil");
  ui.setMarker(1, () => {
    if (quests.sigilsClaimed.length >= 3 && !quests.bossDead) {
      return new THREE.Vector3(LAYOUT.bossArena.x, 10, LAYOUT.bossArena.y);
    }
    return null;
  }, "☠", "mk-boss");
  ui.setMarker(2, () => {
    // nearest unopened chest, only when close-ish
    let best: THREE.Vector3 | null = null;
    let bd = 90 * 90;
    for (const c of world.chests) {
      if (c.opened) continue;
      const d = c.pos.distanceToSquared(player.pos);
      if (d < bd) { bd = d; best = c.pos; }
    }
    return best;
  }, "▣", "mk-chest");

  // ---------- per-frame update
  let autosaveT = 12;
  let hintT = 14;

  const loop = new GameLoop({
    update: (rawDt) => {
      const dt = rawDt * fx.timeScale;

      // global keys
      if (input.consume("mute")) handlers.toggleMute();

      if (state.is("title")) {
        if (input.consume("confirm") || input.consume("dodge")) {
          // Space/Enter starts: continue if a save exists, else new game
          if (save.hasRun()) bootInto("continue");
          else bootInto("new");
        }
        input.clearFrame();
        return;
      }

      if (input.consume("pause")) {
        if (state.is("playing")) {
          state.transition("paused");
          ui.show("pause");
          ui.refreshUpgrades();
          document.exitPointerLock?.();
          writeSave();
          input.clearFrame();
          return;
        } else if (state.is("paused")) {
          state.transition("playing");
          ui.show("none");
          input.clearFrame();
          return;
        } else if (state.is("victory")) {
          handlers.resume();
          input.clearFrame();
          return;
        }
      }

      if (!state.is("playing")) {
        input.clearFrame();
        return;
      }

      // ---- simulate
      playtime += rawDt;
      world.update(dt, elapsed, player.pos);
      player.update(dt, input, world, fx, audio, enemies);
      enemies.update(dt, player);
      quests.update();
      fx.update(dt);
      audio.update(rawDt);

      // interact
      if (input.consume("interact")) quests.interact();

      // music mode
      if (enemies.boss.active && !enemies.boss.dead) audio.setMusic("boss");
      else if (enemies.inCombat()) audio.setMusic("combat");
      else audio.setMusic("explore");

      // HUD
      ui.updateHUD(player.hp, player.maxHp, player.stamina, player.maxStamina, player.xp, XP_CURVE(player.level), player.level);

      // autosave
      autosaveT -= rawDt;
      if (autosaveT <= 0) {
        autosaveT = 12;
        writeSave();
      }
      // hint fade
      if (hintT > 0) {
        hintT -= rawDt;
        ui.setHintVisible(hintT > 0 && !input.usingTouch);
      }

      // auto quality
      if (settings.quality === "auto") {
        fpsTimer += rawDt;
        if (fpsTimer > 2.5) {
          const fps = fpsFrames / fpsTimer;
          if (fps < QUALITY.DEGRADE_FPS) setTier(true);
          else if (fps > 57 && lowTier) setTier(false);
          fpsTimer = 0;
          fpsFrames = 0;
        }
      }

      input.clearFrame();
    },
    render: (alpha) => {
      void alpha;
      // title cinematic orbit around the castle
      if (state.is("title")) {
        titleOrbit += 0.0022;
        const r = 46;
        camera.position.set(
          Math.cos(titleOrbit) * r,
          world.heightAt(Math.cos(titleOrbit) * r, Math.sin(titleOrbit) * r) + 14,
          Math.sin(titleOrbit) * r,
        );
        camera.lookAt(0, 10, 0);
        world.update(1 / 60, elapsed, camera.position);
        fx.update(1 / 60);
        audio.update(1 / 60);
      } else {
        player.updateCamera(camera, world, fx, 1 / 60);
      }

      // sword trail
      player.swordWorld(_bb, _bt);
      fx.updateTrail(player.isAttacking(), _bb, _bt);

      // sky-tinted fog
      const dayF = world.dayFactor;
      (scene.fog as THREE.Fog).color.setRGB(
        0.35 + dayF * 0.35,
        0.42 + dayF * 0.4,
        0.55 + dayF * 0.35,
      ).multiplyScalar(world.raining ? 0.75 : 1);
      (scene.fog as THREE.Fog).near = 70;
      (scene.fog as THREE.Fog).far = 300 + dayF * 260;

      ui.frame(1 / 60, player.camYaw, input.stick, input.usingTouch);
      renderer.render(scene, camera);
      if (!window.__GAME_READY__) window.__GAME_READY__ = true;
      // fps counter for auto-quality
      fpsFrames++;
    },
  });

  let elapsed = 0;

  const clockTimer = setInterval(() => { elapsed += 1 / 60; }, 1000 / 60);

  const onResize = () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight, false);
  };
  window.addEventListener("resize", onResize);

  // verification probe
  window.__gameProbe = () => ({ x: player.pos.x, y: player.pos.y, z: player.pos.z });
  // debug/testing hooks (no visible traces in normal play)
  window.__debug = {
    tp: (x: number, z: number) => { player.pos.set(x, world.heightAt(x, z), z); },
    look: (yaw: number, pitch = 0.3) => { player.camYaw = yaw; player.camPitch = pitch; },
    getState: () => state.state,
    startBoss: () => {
      quests.applySave([0, 1, 2], [], false);
      enemies.boss.activate();
      quests.bossStarted = true;
      ui.showBossBar("Vharzeth, the Shadow Dragon");
      player.pos.set(268 - 15, world.heightAt(253, 60), 60);
    },
    killBoss: () => { enemies.boss.hp = 1; enemies.boss.takeDamage(10, enemies); },
    hurtPlayer: (n: number) => { player.invulnT = 0; player.blockHeld = false; player.godMode = false; player.takeDamage(n, player.pos.x + 1, player.pos.z, audio, fx); },
    god: () => { player.godMode = true; },
    renderInfo: () => ({ calls: renderer.info.render.calls, tris: renderer.info.render.triangles }),
    fps: () => fpsFrames,
  };

  applySettings();
  ui.bindTouch(input);
  ui.setQuest("Claim the Ancient Sigils  (0/3)");
  // initial state: player at spawn, title screen over the live world
  player.spawnAt(LAYOUT.spawn.x, LAYOUT.spawn.y, LAYOUT.spawn.z);
  ui.show("title");
  audio.setMusic("title");
  loop.start();

  const sess: GameSession & { __boot?: (mode: "new" | "continue" | "title") => void } = {
    __boot: (mode) => bootInto(mode),
    dispose: () => {
      loop.stop();
      clearInterval(clockTimer);
      window.removeEventListener("resize", onResize);
      writeSave();
      enemies.dispose();
      player.dispose();
      world.dispose();
      fx.dispose();
      input.dispose();
      audio.dispose();
      ui.dispose();
      renderer.dispose();
      delete window.__gameProbe;
      delete window.__debug;
      window.__GAME_READY__ = false;
    },
  };

  return sess;
}

const _bb = new THREE.Vector3();
const _bt = new THREE.Vector3();

/** Rebuild the session, then boot it into the requested mode. */
function restartInto(canvas: HTMLCanvasElement, mode: "new" | "continue" | "title"): void {
  stopGame();
  const s = createSession(canvas);
  session = s;
  (s as unknown as { __boot(mode: "new" | "continue" | "title"): void }).__boot(mode);
}
